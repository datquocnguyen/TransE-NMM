#include<iostream>
#include<cstring>
#include<cstdio>
#include<map>
#include<vector>
#include<string>
#include<ctime>
#include<cmath>
#include<cstdlib>
#include <algorithm>
#include<sstream>
#include <ctime>
#include <omp.h>
#include <tr1/unordered_map>
#include <Eigen/Dense>
using namespace Eigen;
using namespace std;
using namespace std::tr1;

#define pi 3.1415926535897932384626433832795

//normal distribution
double rand(double min, double max) {
	return min + (max - min) * rand() / (RAND_MAX + 1.0);
}
double normal(double x, double miu, double sigma) {
	return 1.0 / sqrt(2 * pi) / sigma
			* exp(-1 * (x - miu) * (x - miu) / (2 * sigma * sigma));
}
double randn(double miu, double sigma, double min, double max) {
	double x, y, dScope;
	do {
		x = rand(min, max);
		y = normal(x, miu, sigma);
		dScope = rand(0.0, normal(miu, miu, sigma));
	} while (dScope > y);
	return x;
}

double sqr(double x) {
	return x * x;
}

double vec_len(vector<double> &a) {
	double res = 0;
	for (int i = 0; i < a.size(); i++)
		res += a[i] * a[i];
	res = sqrt(res);
	return res;
}

string folder, suffix;
char buf[100000], buf1[100000];
int relation_num, entity_num, nThreads;
map<string, int> relation2id, entity2id;
map<int, string> id2entity, id2relation;

int nepoch = 1000, threshold = 1;

map<int, map<int, int> > left_entity, right_entity;
map<int, double> left_num, right_num;

int myrandom(int i) {
	return std::rand() % i;
}

double cmp(pair<int, double> a, pair<int, double> b) {
	return a.second < b.second;
}

class Train {

public:
	map<pair<int, int>, map<int, int> > triples, dev_test_triples;
	unordered_map<int, map<string, vector<pair<int, int> > > > KBgraph;
	map<int, vector<int> > relTails, relHeads;
	map<int, double> headTailSelector;

	void addDev(int x, int y, int z) {
		dev_fb_h.push_back(x);
		dev_fb_r.push_back(z);
		dev_fb_t.push_back(y);
		//cout << flag << endl;
		//dev_golden.push_back(flag);
		dev_test_triples[make_pair(x, z)][y] = 1;
	}

	void addTest(int x, int y, int z) {
		test_fb_h.push_back(x);
		test_fb_r.push_back(z);
		test_fb_t.push_back(y);
		//cout << flag << endl;
		//test_golden.push_back(flag);
		dev_test_triples[make_pair(x, z)][y] = 1;
	}

	//Input: left entity, right entity, relation
	void add(int x, int y, int z) {
		fb_h.push_back(x); //head entity
		fb_r.push_back(z); // relation
		fb_t.push_back(y); // tail entity
		triples[make_pair(x, z)][y] = 1;

		vector<pair<int, int> > heads = KBgraph[x]["head"], tails =
				KBgraph[y]["tail"];
		heads.push_back(make_pair(z, y));
		tails.push_back(make_pair(z, x));
		KBgraph[x]["head"] = heads;
		KBgraph[y]["tail"] = tails;

		vector<int> heads1 = relHeads[z];
		vector<int> tails1 = relTails[z];
		//heads.push_back(x);
		//tails.push_back(y);

		if (std::find(heads1.begin(), heads1.end(), x) != heads1.end()) {
			/* v contains x */
		} else {
			heads1.push_back(x);
		}

		if (std::find(tails1.begin(), tails1.end(), y) != tails1.end()) {
			/* v contains x */
		} else {
			tails1.push_back(y);
		}

		relHeads[z] = heads1;
		relTails[z] = tails1;
	}

	void removeNoiseHead() {
		for (int i = 0; i < entity_num; i++) {
			vector<pair<int, int> > heads = KBgraph[i]["head"];

			map<int, int> countRelH;
			for (int x = 0; x < heads.size(); x++) {
				countRelH[heads[x].first] += 1;
			}

			vector<pair<int, int> > newHeads;
			for (int x = 0; x < heads.size(); x++) {
				if (countRelH[heads[x].first] <= threshold)
					newHeads.push_back(heads[x]);
			}

			KBgraph[i]["head"] = newHeads;
		}
	}

	void removeNoiseTail() {
		for (int i = 0; i < entity_num; i++) {
			vector<pair<int, int> > heads = KBgraph[i]["tail"];

			map<int, int> countRelH;
			for (int x = 0; x < heads.size(); x++) {
				countRelH[heads[x].first] += 1;
			}

			vector<pair<int, int> > newHeads;
			for (int x = 0; x < heads.size(); x++) {
				if (countRelH[heads[x].first] <= threshold)
					newHeads.push_back(heads[x]);
			}

			KBgraph[i]["tail"] = newHeads;
		}
	}

	void run(int n_in, double rate_in, double rateW_in, double margin_in,
			bool method_in, int iah, int ibh, int iat, int ibt, int opt_in,
			bool l1_in, bool rms_in, int nneg_in, double scale_in,
			double regularizer_in, int d_in, bool init_in) {
		n = n_in;
		rate = rate_in;
		rateW = rateW_in;
		margin = margin_in;
		relGivenSample = method_in;
		ah = iah;
		bh = ibh;
		at = iat;
		bt = ibt;

		opt = opt_in;
		L1_flag = l1_in;
		rms = rms_in;
		nneg = nneg_in;
		scale = scale_in;
		regularizer = regularizer_in;
		dscale = d_in;
		ranInit = init_in;

		removeNoiseHead();
		removeNoiseTail();

		cout << "L1: " << L1_flag << endl;
		cout << "load: " << ah << bh << at << bt << endl;

//		for (int x = 0; x < 1; x++) {
//			vector<pair<int, int> > heads = KBgraph[x]["head"], tails =
//					KBgraph[x]["tail"];
//
//			cout << x << " " << heads.size() << " " << tails.size() << endl;
//		}

		alpha_head.resize(relation_num);
		best_alpha_head.resize(relation_num);
		exp_alpha_head.resize(relation_num);
		for (int i = 0; i < alpha_head.size(); i++) {
			alpha_head[i].setZero(relation_num);
			best_alpha_head[i].setZero(relation_num);
			exp_alpha_head[i].setZero(relation_num);
		}

		beta_head.resize(relation_num);
		best_beta_head.resize(relation_num);
		exp_beta_head.resize(relation_num);
		for (int i = 0; i < beta_head.size(); i++) {
			beta_head[i].setZero(relation_num);
			best_beta_head[i].setZero(relation_num);
			exp_beta_head[i].setZero(relation_num);
		}

		alpha_tail.resize(relation_num);
		best_alpha_tail.resize(relation_num);
		exp_alpha_tail.resize(relation_num);
		for (int i = 0; i < alpha_tail.size(); i++) {
			alpha_tail[i].setZero(relation_num);
			best_alpha_tail[i].setZero(relation_num);
			exp_alpha_tail[i].setZero(relation_num);
		}

		beta_tail.resize(relation_num);
		best_beta_tail.resize(relation_num);
		exp_beta_tail.resize(relation_num);
		for (int i = 0; i < beta_tail.size(); i++) {
			beta_tail[i].setZero(relation_num);
			best_beta_tail[i].setZero(relation_num);
			exp_beta_tail[i].setZero(relation_num);
		}

		for (int i = 0; i < relation_num; i++) {
			for (int j = 0; j < relation_num; j++) {
				if (ah)
					alpha_head[i][j] = 0.0;
				if (bh)
					beta_head[i][j] = 0.0;
				if (at)
					alpha_tail[i][j] = 0.0;
				if (bt)
					beta_tail[i][j] = 0.0;
			}
		}

		aHead_tmp.resize(relation_num);
		for (int i = 0; i < alpha_head.size(); i++)
			aHead_tmp[i].setZero(relation_num);

		bHead_tmp.resize(relation_num);
		for (int i = 0; i < beta_head.size(); i++)
			bHead_tmp[i].setZero(relation_num);

		aTail_tmp.resize(relation_num);
		for (int i = 0; i < alpha_tail.size(); i++)
			aTail_tmp[i].setZero(relation_num);

		bTail_tmp.resize(relation_num);
		for (int i = 0; i < beta_tail.size(); i++) {
			bTail_tmp[i].setZero(relation_num);
		}

		relation_vec.resize(relation_num);
		best_relation_vec.resize(relation_num);
		for (int i = 0; i < relation_vec.size(); i++) {
			relation_vec[i].resize(n);
			best_relation_vec[i].resize(n);
		}

		linkPredictionValues.resize(10);
		for (int i = 0; i < 10; i++)
			linkPredictionValues[i] = 0.0;

		WuE.resize(entity_num);
		best_WuE.resize(entity_num);
		exp_WuE.resize(entity_num);
		WuE_tmp.resize(entity_num);
		parFuncValues.resize(entity_num);
		for (int i = 0; i < WuE.size(); i++) {
			WuE[i] = 0.0;
			best_WuE[i] = 0.0;
			exp_WuE[i] = 0.0;
			WuE_tmp[i] = 0.0;
			parFuncValues[i] = 0.0;
		}

		for (int i = 0; i < relation_num; i++) {
			headTailSelector[i] = 1000 * right_num[i]
					/ (right_num[i] + left_num[i]);
		}

		uEntity_vec.resize(entity_num);
		best_uEntity_vec.resize(entity_num);
		for (int i = 0; i < uEntity_vec.size(); i++) {
			uEntity_vec[i].resize(n);
			best_uEntity_vec[i].resize(n);
		}

		if (ranInit) {
			FILE* f1 = fopen((folder + "entity2vec.init").c_str(), "r");
			for (int i = 0; i < entity_num; i++) {
				for (int ii = 0; ii < n; ii++)
					fscanf(f1, "%lf", &uEntity_vec[i][ii]);
				norm(uEntity_vec[i]);
			}
			fclose(f1);

			FILE* f2 = fopen((folder + "relation2vec.init").c_str(), "r");
			for (int i = 0; i < relation_num; i++) {
				for (int ii = 0; ii < n; ii++)
					fscanf(f2, "%lf", &relation_vec[i][ii]);
			}
			fclose(f2);

			f1 = fopen((folder + "Eweights.init").c_str(), "r");
			for (int i = 0; i < entity_num; i++) {
				fscanf(f1, "%lf", &WuE[i]);
			}
			fclose(f1);

			f2 = fopen((folder + "Rweights.init").c_str(), "r");

			for (int i = 0; i < relation_num; i++) {
				for (int ii = 0; ii < relation_num; ii++) {
					fscanf(f2, "%lf", &alpha_head[i][ii]);
				}
			}
			for (int i = 0; i < relation_num; i++) {
				for (int ii = 0; ii < relation_num; ii++) {
					fscanf(f2, "%lf", &beta_head[i][ii]);
				}
			}
			for (int i = 0; i < relation_num; i++) {
				for (int ii = 0; ii < relation_num; ii++) {
					fscanf(f2, "%lf", &alpha_tail[i][ii]);
				}
			}
			for (int i = 0; i < relation_num; i++) {
				for (int ii = 0; ii < relation_num; ii++) {
					fscanf(f2, "%lf", &beta_tail[i][ii]);
				}
			}
			fclose(f2);

		} else {
			for (int i = 0; i < relation_num; i++) {
				for (int ii = 0; ii < n; ii++)
					relation_vec[i][ii] = randn(0, 1.0 / n, -6 / sqrt(n),
							6 / sqrt(n));
				//norm(relation_vec[i]);
			}

			for (int i = 0; i < entity_num; i++) {
				for (int ii = 0; ii < n; ii++)
					uEntity_vec[i][ii] = randn(0, 1.0 / n, -6 / sqrt(n),
							6 / sqrt(n));
				norm(uEntity_vec[i]);
			}
		}

		reset();

		//initializeWeights();

		cout << "run Test \n";

		computeExp();

//		//for (int i = 0; i < 600; i++) {
//		//	cout << i << endl;
//		clock_t begin = time(0);
//		cout << runRelationPrediction_Dev() << endl;
//		cout << "Time1: " << difftime(time(0), begin) << " " << endl;
//		begin = time(0);
//		runRelationPrediction_Test(linkPredictionValues);
//		cout << "Time2: " << difftime(time(0), begin) << " " << endl;
//		printf("%s %.6lf %.6lf %.6lf %.6lf %.6lf\n", "RAW-test:",
//				linkPredictionValues[0], linkPredictionValues[1],
//				linkPredictionValues[2], linkPredictionValues[3],
//				linkPredictionValues[4]);
//		printf("%s %.6lf %.6lf %.6lf %.6lf %.6lf\n", "Filter-test:",
//				linkPredictionValues[5], linkPredictionValues[6],
//				linkPredictionValues[7], linkPredictionValues[8],
//				linkPredictionValues[9]);
//		//	}

		aHead_tmp = alpha_head;
		bHead_tmp = beta_head;
		aTail_tmp = alpha_tail;
		bTail_tmp = beta_tail;
		WuE_tmp = WuE;
		best_alpha_head = alpha_head;
		best_beta_head = beta_head;
		best_alpha_tail = alpha_tail;
		best_beta_tail = beta_tail;
		best_WuE = WuE;
		relation_tmp = relation_vec;
		uEntity_tmp = uEntity_vec;
		best_relation_vec = relation_vec;
		best_uEntity_vec = uEntity_vec;

		cout << "Optimizing ...\n";

		if (opt == 0) {
			//	int index = 0;
			gradientChecking(0.00000001, false);
			gradientChecking(0.00000001, true);
			cout << "\n --------------- " << endl;
			gradientChecking1(0.00000001, false);
			gradientChecking1(0.00000001, true);
			cout << "\n --------------- " << endl;
			gradientChecking2(0.00000001);
			cout << "\n --------------- " << endl;
			gradientChecking3(0.00000001, 1);
			cout << "\n --------------- " << endl;
			gradientChecking3(0.00000001, 2);
			cout << "\n --------------- " << endl;
			gradientChecking3(0.00000001, 3);
			cout << "\n --------------- " << endl;
			gradientChecking3(0.00000001, 4);
		}
		if (opt == 1)
			optimize1();
		if (opt == 2)
			optimize2();
		//if (opt == 3)
		//	optimize1_2();
		//if (opt == 4)
		//	optimize2_2();
		//gradientChecking();

	}

	void reset() {
		WuE_grad.resize(entity_num);
		WuE_Eg.resize(entity_num);
		WuE_Edelta.resize(entity_num);
		for (int i = 0; i < WuE_grad.size(); i++) {
			WuE_grad[i] = 0.0;
			WuE_Eg[i] = 0.0;
			WuE_Edelta[i] = 0.0;
		}

		aHead_grad.resize(relation_num);
		aHead_Eg.resize(relation_num);
		aHead_Edelta.resize(relation_num);
		for (int i = 0; i < aHead_grad.size(); i++) {
			aHead_grad[i].setZero(relation_num);
			aHead_Eg[i].setZero(relation_num);
			aHead_Edelta[i].setZero(relation_num);
		}

		bHead_grad.resize(relation_num);
		bHead_Eg.resize(relation_num);
		bHead_Edelta.resize(relation_num);
		for (int i = 0; i < bHead_grad.size(); i++) {
			bHead_grad[i].setZero(relation_num);
			bHead_Eg[i].setZero(relation_num);
			bHead_Edelta[i].setZero(relation_num);
		}

		aTail_grad.resize(relation_num);
		aTail_Eg.resize(relation_num);
		aTail_Edelta.resize(relation_num);
		for (int i = 0; i < aTail_grad.size(); i++) {
			aTail_grad[i].setZero(relation_num);
			aTail_Eg[i].setZero(relation_num);
			aTail_Edelta[i].setZero(relation_num);
		}

		bTail_grad.resize(relation_num);
		bTail_Eg.resize(relation_num);
		bTail_Edelta.resize(relation_num);
		for (int i = 0; i < bTail_grad.size(); i++) {
			bTail_grad[i].setZero(relation_num);
			bTail_Eg[i].setZero(relation_num);
			bTail_Edelta[i].setZero(relation_num);
		}

		relEg.resize(relation_num);
		relEdelta.resize(relation_num);
		relation_grad.resize(relation_num);
		relation_tmp.resize(relation_num);
		for (int i = 0; i < relation_grad.size(); i++) {
			relation_grad[i].setZero(n);
			relEg[i].setZero(n);
			relEdelta[i].setZero(n);
			relation_tmp[i].resize(n);
		}
		uEntity_grad.resize(entity_num);
		enEg.resize(entity_num);
		enEdelta.resize(entity_num);
		uEntity_tmp.resize(entity_num);
		for (int i = 0; i < uEntity_grad.size(); i++) {
			uEntity_grad[i].setZero(n);
			enEg[i].setZero(n);
			enEdelta[i].setZero(n);
			uEntity_tmp[i].resize(n);
		}

	}

	void gradientChecking(double deltaX, bool isHead) {
		cout.precision(10);
		cout << "Gradient checking 0 .... \n";

		aHead_tmp = alpha_head;
		bHead_tmp = beta_head;
		aTail_tmp = alpha_tail;
		bTail_tmp = beta_tail;
		WuE_tmp = WuE;
		relation_tmp = relation_vec;
		uEntity_tmp = uEntity_vec;

		double sum = 0.0;
		for (int index = 0; index < 10000; index++) {

			//cout << index << endl;

			int head = fb_h[index], tail = fb_t[index], rel = fb_r[index];

			int temp;
			for (int j = 0; j < entity_num; j++) {
				if (triples[make_pair(head, rel)].count(j) > 0)
					continue;

				double sum1 = calc_simValue(head, tail, rel);
				double sum2 = calc_simValue(head, j, rel);

				if (sum1 + margin <= sum2)
					continue;
				else {
					temp = j;
					break;
				}
			}

			int j = temp;

			VectorXd disPos, disNeg, headVec, tailVec;

			if (isHead) {
				WuE[head] = WuE_tmp[head] + deltaX;
				exp_WuE[head] = exp(WuE[head]);
			} else {
				WuE[tail] = WuE_tmp[tail] + deltaX;
				exp_WuE[tail] = exp(WuE[tail]);
			}

			double empirical1 = calc_simValue(head, tail, rel, disPos) + margin
					- calc_simValue(head, j, rel);

			if (isHead) {
				WuE[head] = WuE_tmp[head] - deltaX;
				exp_WuE[head] = exp(WuE[head]);
			} else {
				WuE[tail] = WuE_tmp[tail] - deltaX;
				exp_WuE[tail] = exp(WuE[tail]);
			}

			double empirical2 = calc_simValue(head, tail, rel, disNeg) + margin
					- calc_simValue(head, j, rel);
			double empirical = (empirical1 - empirical2) / (2 * deltaX);

			//cout << empirical1 << " " << empirical2 << " " << empirical << endl;

			if (isHead) {
				WuE[head] = WuE_tmp[head];
				exp_WuE[head] = exp(WuE[head]);
			} else {
				WuE[tail] = WuE_tmp[tail];
				exp_WuE[tail] = exp(WuE[tail]);
			}

			if (isHead)
				WuE_grad[head] = 0;
			else
				WuE_grad[tail] = 0;

			map<string, map<int, int> > neiRelations;
			map<int, int> entities;
			double pos_PFVHead = 0.0, pos_PFVTail = 0.0, neg_PFVHead = 0.0,
					neg_PFVTail = 0.0;

			double sum1 = calc_simValue(head, tail, rel, pos_PFVHead,
					pos_PFVTail, headVec, tailVec, disPos);
			computeGradientM(head, tail, rel, pos_PFVHead, pos_PFVTail, headVec,
					tailVec, disPos, 1);

			double sum2 = calc_simValue(head, j, rel, neg_PFVHead, neg_PFVTail,
					headVec, tailVec, disNeg);
			computeGradientM(head, j, rel, neg_PFVHead, neg_PFVTail, headVec,
					tailVec, disNeg, -1);

			if (isHead)
				sum += abs(empirical - WuE_grad[head]);
			else
				sum += abs(empirical - WuE_grad[tail]);
		}

		cout << sum / (10000) << endl;
	}

	void gradientChecking3(double deltaX, int isHead) {
		cout.precision(10);
		cout << "Gradient checking 3 .... \n";

		aHead_tmp = alpha_head;
		bHead_tmp = beta_head;
		aTail_tmp = alpha_tail;
		bTail_tmp = beta_tail;
		WuE_tmp = WuE;
		relation_tmp = relation_vec;
		uEntity_tmp = uEntity_vec;

		double sum = 0.0;

		for (int index = 0; index < 10000; index++) {

			int head = fb_h[index], tail = fb_t[index], rel = fb_r[index];
			int tmp;
			for (int j = 0; j < entity_num; j++) {
				if (triples[make_pair(head, rel)].count(j) > 0)
					continue;

				double sum1 = calc_simValue(head, tail, rel);
				double sum2 = calc_simValue(head, j, rel);

				if (sum1 + margin <= sum2)
					continue;
				else {
					tmp = j;
					break;
				}
			}

			int j = tmp;

			for (int inRel = 0; inRel < relation_num; inRel++) {
				VectorXd disPos, disNeg, headVec, tailVec;

				if (isHead == 1) {
					alpha_head[rel][inRel] = aHead_tmp[rel][inRel] + deltaX;
					double temp = alpha_head[rel][inRel];
					exp_alpha_head[rel][inRel] = exp(temp);
				} else if (isHead == 2) {
					beta_head[rel][inRel] = bHead_tmp[rel][inRel] + deltaX;
					double temp = beta_head[rel][inRel];
					exp_beta_head[rel][inRel] = exp(temp);
				} else if (isHead == 3) {
					alpha_tail[rel][inRel] = aTail_tmp[rel][inRel] + deltaX;
					double temp = alpha_tail[rel][inRel];
					exp_alpha_tail[rel][inRel] = exp(temp);
				} else if (isHead == 4) {
					beta_tail[rel][inRel] = bTail_tmp[rel][inRel] + deltaX;
					double temp = beta_tail[rel][inRel];
					exp_beta_tail[rel][inRel] = exp(temp);
				} else
					return;

				double empirical1 = calc_simValue(head, tail, rel, disPos)
						+ margin - calc_simValue(head, j, rel);

				if (isHead == 1) {
					alpha_head[rel][inRel] = aHead_tmp[rel][inRel] - deltaX;
					double temp = alpha_head[rel][inRel];
					exp_alpha_head[rel][inRel] = exp(temp);
				} else if (isHead == 2) {
					beta_head[rel][inRel] = bHead_tmp[rel][inRel] - deltaX;
					double temp = beta_head[rel][inRel];
					exp_beta_head[rel][inRel] = exp(temp);
				} else if (isHead == 3) {
					alpha_tail[rel][inRel] = aTail_tmp[rel][inRel] - deltaX;
					double temp = alpha_tail[rel][inRel];
					exp_alpha_tail[rel][inRel] = exp(temp);
				} else if (isHead == 4) {
					beta_tail[rel][inRel] = bTail_tmp[rel][inRel] - deltaX;
					double temp = beta_tail[rel][inRel];
					exp_beta_tail[rel][inRel] = exp(temp);
				}

				double empirical2 = calc_simValue(head, tail, rel, disNeg)
						+ margin - calc_simValue(head, j, rel);
				double empirical = (empirical1 - empirical2) / (2 * deltaX);

				//cout << empirical1 << " " << empirical2 << " " << empirical << endl;

				if (isHead == 1) {
					alpha_head[rel][inRel] = aHead_tmp[rel][inRel];
					double temp = alpha_head[rel][inRel];
					exp_alpha_head[rel][inRel] = exp(temp);
				} else if (isHead == 2) {
					beta_head[rel][inRel] = bHead_tmp[rel][inRel];
					double temp = beta_head[rel][inRel];
					exp_beta_head[rel][inRel] = exp(temp);
				} else if (isHead == 3) {
					alpha_tail[rel][inRel] = aTail_tmp[rel][inRel];
					double temp = alpha_tail[rel][inRel];
					exp_alpha_tail[rel][inRel] = exp(temp);
				} else if (isHead == 4) {
					beta_tail[rel][inRel] = bTail_tmp[rel][inRel];
					double temp = beta_tail[rel][inRel];
					exp_beta_tail[rel][inRel] = exp(temp);
				}

				if (isHead == 1) {
					aHead_grad[rel][inRel] = 0;
				} else if (isHead == 2) {
					bHead_grad[rel][inRel] = 0;
				} else if (isHead == 3) {
					aTail_grad[rel][inRel] = 0;
				} else if (isHead == 4) {
					bTail_grad[rel][inRel] = 0;
				}

				map<string, map<int, int> > neiRelations;
				map<int, int> entities;
				double pos_PFVHead = 0.0, pos_PFVTail = 0.0, neg_PFVHead = 0.0,
						neg_PFVTail = 0.0;

				double sum1 = calc_simValue(head, tail, rel, pos_PFVHead,
						pos_PFVTail, headVec, tailVec, disPos);
				computeGradientM(head, tail, rel, pos_PFVHead, pos_PFVTail,
						headVec, tailVec, disPos, 1);

				double sum2 = calc_simValue(head, j, rel, neg_PFVHead,
						neg_PFVTail, headVec, tailVec, disNeg);
				computeGradientM(head, j, rel, neg_PFVHead, neg_PFVTail,
						headVec, tailVec, disNeg, -1);

				if (isHead == 1) {
					double temp = aHead_grad[rel][inRel];
					sum += abs(temp - empirical);
				} else if (isHead == 2) {
					double temp = bHead_grad[rel][inRel];
					sum += abs(temp - empirical);
				} else if (isHead == 3) {
					double temp = aTail_grad[rel][inRel];
					sum += abs(temp - empirical);
				} else if (isHead == 4) {
					double temp = bTail_grad[rel][inRel];
					sum += abs(temp - empirical);
				}
			}

		}
		cout << sum / (10000 * relation_num) << endl;
	}

	void gradientChecking1(double deltaX, bool isHead) {
		cout.precision(10);
		cout << "Gradient checking 1 .... \n";

		aHead_tmp = alpha_head;
		bHead_tmp = beta_head;
		aTail_tmp = alpha_tail;
		bTail_tmp = beta_tail;
		WuE_tmp = WuE;
		relation_tmp = relation_vec;
		uEntity_tmp = uEntity_vec;

		double sum = 0.0;
		for (int index = 0; index < 10000; index++) {
			int head = fb_h[index], tail = fb_t[index], rel = fb_r[index];
			int tmp;
			for (int j = 0; j < entity_num; j++) {
				if (triples[make_pair(head, rel)].count(j) > 0)
					continue;

				double sum1 = calc_simValue(head, tail, rel);
				double sum2 = calc_simValue(head, j, rel);

				if (sum1 + margin <= sum2)
					continue;
				else {
					tmp = j;
					break;
				}
			}

			int j = tmp;

			VectorXd disPos, disNeg, headVec, tailVec;

			for (int k = 0; k < n; k++) {

				if (isHead)
					uEntity_vec[head][k] = uEntity_tmp[head][k] + deltaX;
				else
					uEntity_vec[tail][k] = uEntity_tmp[tail][k] + deltaX;

				double empirical1 = calc_simValue(head, tail, rel, disPos)
						+ margin - calc_simValue(head, j, rel);

				if (isHead)
					uEntity_vec[head][k] = uEntity_tmp[head][k] - deltaX;
				else
					uEntity_vec[tail][k] = uEntity_tmp[tail][k] - deltaX;

				double empirical2 = calc_simValue(head, tail, rel, disNeg)
						+ margin - calc_simValue(head, j, rel);
				double empirical = (empirical1 - empirical2) / (2 * deltaX);

				if (isHead)
					uEntity_vec[head][k] = uEntity_tmp[head][k];
				else
					uEntity_vec[tail][k] = uEntity_tmp[tail][k];

				if (isHead)
					uEntity_grad[head][k] = 0;
				else
					uEntity_grad[tail][k] = 0;

				map<string, map<int, int> > neiRelations;
				map<int, int> entities, relations;
				double pos_PFVHead = 0.0, pos_PFVTail = 0.0, neg_PFVHead = 0.0,
						neg_PFVTail = 0.0;

				double sum1 = calc_simValue(head, tail, rel, pos_PFVHead,
						pos_PFVTail, headVec, tailVec, disPos);
				computeGradient(head, tail, rel, pos_PFVHead, pos_PFVTail,
						disPos, 1);

				double sum2 = calc_simValue(head, j, rel, neg_PFVHead,
						neg_PFVTail, headVec, tailVec, disNeg);
				computeGradient(head, j, rel, neg_PFVHead, neg_PFVTail, disNeg,
						-1);

				double temp = 0.0;
				if (isHead) {
					temp = uEntity_grad[head][k];
					sum += abs(empirical - temp);
				} else {
					temp = uEntity_grad[tail][k];
					sum += abs(empirical - temp);
				}

			}
		}
		cout << sum / (10000 * n) << endl;
	}

	void gradientChecking2(double deltaX) {
		cout.precision(10);
		cout << "Gradient checking 2 .... \n";

		aHead_tmp = alpha_head;
		bHead_tmp = beta_head;
		aTail_tmp = alpha_tail;
		bTail_tmp = beta_tail;
		WuE_tmp = WuE;
		relation_tmp = relation_vec;
		uEntity_tmp = uEntity_vec;

		double sum = 0.0;
		for (int index = 0; index < 10000; index++) {
			int head = fb_h[index], tail = fb_t[index], rel = fb_r[index];
			int tmp;
			for (int j = 0; j < entity_num; j++) {
				if (triples[make_pair(head, rel)].count(j) > 0)
					continue;

				double sum1 = calc_simValue(head, tail, rel);
				double sum2 = calc_simValue(head, j, rel);

				if (sum1 + margin <= sum2)
					continue;
				else {
					tmp = j;
					break;
				}
			}

			int j = tmp;

			VectorXd disPos, disNeg, headVec, tailVec;

			for (int k = 0; k < n; k++) {

				relation_vec[rel][k] = relation_tmp[rel][k] + deltaX;

				double empirical1 = calc_simValue(head, tail, rel, disPos)
						+ margin - calc_simValue(head, j, rel);

				relation_vec[rel][k] = relation_tmp[rel][k] - deltaX;

				double empirical2 = calc_simValue(head, tail, rel, disNeg)
						+ margin - calc_simValue(head, j, rel);

				double empirical = (empirical1 - empirical2) / (2 * deltaX);

//				cout << empirical1 << " " << empirical2 << " " << empirical
//						<< endl;

				relation_vec[rel][k] = relation_tmp[rel][k];
				relation_grad[rel][k] = 0.0;

				map<string, map<int, int> > neiRelations;
				map<int, int> entities, relations;
				double pos_PFVHead = 0.0, pos_PFVTail = 0.0, neg_PFVHead = 0.0,
						neg_PFVTail = 0.0;

				double sum1 = calc_simValue(head, tail, rel, pos_PFVHead,
						pos_PFVTail, headVec, tailVec, disPos);
				computeGradient(head, tail, rel, pos_PFVHead, pos_PFVTail,
						disPos, 1);

				double sum2 = calc_simValue(head, j, rel, neg_PFVHead,
						neg_PFVTail, headVec, tailVec, disNeg);
				computeGradient(head, j, rel, neg_PFVHead, neg_PFVTail, disNeg,
						-1);

				double temp = relation_grad[rel][k];
				sum += abs(empirical - temp);
			}

		}
		cout << sum / (10000 * n) << endl;
	}

private:
	int n, ah, bh, at, bt, opt, nneg, dscale;
	double res, scale, regularizer; //loss function value
	double count, count1; //loss function gradient
	double rate, margin, rateW;
	double belta;
	vector<int> fb_h, fb_t, fb_r; //head, tail, relation
	vector<VectorXd> relation_vec, uEntity_vec;
	vector<VectorXd> best_relation_vec, best_uEntity_vec;
	double bestValidScore = 0.0;

	vector<VectorXd> relation_tmp, uEntity_tmp;
	vector<VectorXd> relation_grad, uEntity_grad;
	vector<VectorXd> relEg, relEdelta, enEg, enEdelta;

	vector<double> WuE, best_WuE, exp_WuE, WuE_tmp, WuE_grad, WuE_Eg,
			WuE_Edelta, parFuncValues, linkPredictionValues;

	vector<VectorXd> alpha_head, beta_head, alpha_tail, beta_tail;
	vector<VectorXd> best_alpha_head, best_beta_head, best_alpha_tail,
			best_beta_tail;
	vector<VectorXd> exp_alpha_head, exp_beta_head, exp_alpha_tail,
			exp_beta_tail;
	vector<VectorXd> aHead_tmp, bHead_tmp, aTail_tmp, bTail_tmp;
	vector<VectorXd> aHead_grad, bHead_grad, aTail_grad, bTail_grad;
	vector<VectorXd> aHead_Eg, bHead_Eg, aTail_Eg, bTail_Eg;
	vector<VectorXd> aHead_Edelta, bHead_Edelta, aTail_Edelta, bTail_Edelta;

	bool L1_flag = 1, rms = 1, ranInit, relGivenSample;

	vector<int> dev_fb_h, dev_fb_t, dev_fb_r;
	vector<bool> dev_golden;

	vector<int> test_fb_h, test_fb_t, test_fb_r;
	vector<bool> test_golden;

//	double norm(vector<double> &a) {
//		double x = vec_len(a);
//		if (x > 1)
//			for (int ii = 0; ii < a.size(); ii++)
//				a[ii] /= x;
//		return 0;
//	}

	void norm(VectorXd &a) {
		if (a.norm() > 1)
			a.normalize();
	}

	void norm(VectorXd &a, VectorXd &b, VectorXd &c, VectorXd &d) {
		double values[] = { a.norm(), b.norm(), c.norm(), d.norm() };
		double max = *max_element(values, values + 4);
		if (max > 1) {
			a = a / max;
			b = b / max;
			c = c / max;
			d = d / max;
		}
	}

//	int rand_max(int x) {
//		int res = (rand() * rand()) % x;
//		while (res < 0)
//			res += x;
//		return res;
//	}

	void optimize1() {

		FILE* f2 = fopen((folder + suffix + ".log.txt").c_str(), "w");
		computeExp();
		reset();
		optimizeVectors(f2);
		computeExp();
		reset();
		optimizeWeights(f2);
		computeExp();
		reset();
		optimizeVectors(f2);

		fclose(f2);

		write();
	}

	void optimize2() {

		FILE* f2 = fopen((folder + suffix + ".log.txt").c_str(), "w");

		computeExp();
		reset();
		optimizeVectors(f2);
		computeExp();
		reset();
		optimizeWeights(f2);
		computeExp();
		reset();
		optimizeWeightsVectors(f2);

		fclose(f2);

		write();
	}

	void optimizeWeightsVectors(FILE* f2) {

		for (int epoch = 0; epoch < nepoch; epoch++) {
			res = 0;
			aHead_tmp = alpha_head;
			bHead_tmp = beta_head;
			aTail_tmp = alpha_tail;
			bTail_tmp = beta_tail;
			WuE_tmp = WuE;
			relation_tmp = relation_vec;
			uEntity_tmp = uEntity_vec;
			computeExp();

			//vector<int> trainingIDs;
			for (int i = 0; i < fb_h.size(); ++i) {
				//	trainingIDs.push_back(i);
				//random_shuffle(trainingIDs.begin(), trainingIDs.end(),
				//		myrandom);
				//	for (std::vector<int>::iterator it = trainingIDs.begin();
				//		it != trainingIDs.end(); ++it) {
				//	int i = *it;
				//	//cout << i << endl;
				//	//int i=rand_max(fb_h.size());

				int head = fb_h[i], tail = fb_t[i], rel = fb_r[i];

				double pr = headTailSelector[rel];

				map<int, int> wEntities;
				map<string, map<int, int> > neiWRelations;
				map<int, int> entities, relations;

				if (relGivenSample) {
					for (int index = 0; index < nneg; index++) {
						//int j = rand() % entity_num;
						if (rand() % 1000 < pr) {
							vector<int> tails = relTails[rel];
							int sizeT = tails.size();
							int j = tails[rand() % sizeT];
							int numSample = -1;
							while (triples[make_pair(head, rel)].count(j) > 0) {
								numSample++;
								if (numSample > sizeT)
									j = rand() % entity_num;
								else
									j = tails[rand() % sizeT];
							}

							train_kb_Estep(head, tail, rel, j, true, entities,
									relations);

							train_kb_Mstep(head, tail, rel, j, true, wEntities,
									neiWRelations);

							wEntities[j] += 1;
						} else {
							vector<int> heads = relHeads[rel];
							int sizeH = heads.size();
							int j = heads[rand() % sizeH];
							int numSample = -1;
							while (triples[make_pair(j, rel)].count(tail) > 0) {
								numSample++;
								if (numSample > sizeH)
									j = rand() % entity_num;
								else
									j = heads[rand() % sizeH];
							}

							train_kb_Estep(head, tail, rel, j, false, entities,
									relations);

							train_kb_Mstep(head, tail, rel, j, false, wEntities,
									neiWRelations);
							wEntities[j] += 1;
						}
					}
				} else {
					for (int index = 0; index < nneg; index++) {
						//int j = rand() % entity_num;
						if (rand() % 1000 < pr) {
							int j = rand() % entity_num;
							while (triples[make_pair(head, rel)].count(j) > 0)
								j = rand() % entity_num;

							train_kb_Estep(head, tail, rel, j, true, entities,
									relations);

							train_kb_Mstep(head, tail, rel, j, true, wEntities,
									neiWRelations);
							wEntities[j] += 1;
						} else {
							int j = rand() % entity_num;
							while (triples[make_pair(j, rel)].count(tail) > 0)
								j = rand() % entity_num;

							train_kb_Estep(head, tail, rel, j, false, entities,
									relations);
							train_kb_Mstep(head, tail, rel, j, false, wEntities,
									neiWRelations);
							wEntities[j] += 1;
						}
					}
				}

				if (rms)
					RMSProp_updateM(wEntities, rel, neiWRelations);
				else
					AdaDelta_updateM(wEntities, rel, neiWRelations);

				if (rms)
					RMSProp_update(entities, relations);
				else
					AdaDelta_update(entities, relations);

				for (map<int, int>::iterator it = entities.begin();
						it != entities.end(); ++it) {
					int id = it->first;
					norm(uEntity_tmp[id]);
					uEntity_vec[id] = uEntity_tmp[id];
				}
				for (map<int, int>::iterator it = relations.begin();
						it != relations.end(); ++it) {
					int id = it->first;
					norm(relation_tmp[id]);
					relation_vec[id] = relation_tmp[id];
				}

				double temp = 0.0;
				for (int it = 0; it < relation_num; it++) {
					temp = aHead_tmp[rel][it];
					alpha_head[rel][it] = temp;
					exp_alpha_head[rel][it] = exp(temp);

					temp = bHead_tmp[rel][it];
					beta_head[rel][it] = temp;
					exp_beta_head[rel][it] = exp(temp);

					temp = aTail_tmp[rel][it];
					alpha_tail[rel][it] = temp;
					exp_alpha_tail[rel][it] = exp(temp);

					temp = bTail_tmp[rel][it];
					beta_tail[rel][it] = temp;
					exp_beta_tail[rel][it] = exp(temp);
				}

				for (map<int, int>::iterator it = wEntities.begin();
						it != wEntities.end(); ++it) {
					int id = it->first;
					WuE[id] = WuE_tmp[id];
					exp_WuE[id] = exp(WuE[id]);
				}

			}
			WuE = WuE_tmp;
			alpha_head = aHead_tmp;
			beta_head = bHead_tmp;
			alpha_tail = aTail_tmp;
			beta_tail = bTail_tmp;
			relation_vec = relation_tmp;
			uEntity_vec = uEntity_tmp;

			cout << "---\nepoch:" << epoch << "-> (Train):  " << res << endl;

			//double heldOutloss = computeLossFuncHeldout();
			//cout << "-> (Dev):  " << heldOutloss << endl;

			fprintf(f2, "%s %d %s %.6lf\n", "---\nepoch:", epoch,
					"-> (Train):  ", res);
			//fprintf(f2, "%s %.6lf\n", "-> (Dev):  ", heldOutloss);

			double validScore = runRelationPrediction_Dev();
			cout << "Filtered MRR on valid set: " << validScore << endl;
			//runLinkPrediction_Test();
			fprintf(f2, "%s %.6lf\n", "Filtered MRR on valid set:",
					validScore);
			//fprintf(f2, "%s %.6lf\n", "Accuracy on test set:", testRel);

			if (bestValidScore < validScore) {
				bestValidScore = validScore;
				//bestTestScore = testRel;
				best_alpha_head = alpha_head;
				best_beta_head = beta_head;
				best_alpha_tail = alpha_tail;
				best_beta_tail = beta_tail;
				best_WuE = WuE;
				best_uEntity_vec = uEntity_vec;
				best_relation_vec = relation_vec;
			}
		}

		cout << "---\nBest filtered MRR on valid set: " << bestValidScore
				<< endl;

		fprintf(f2, "%s %.6lf\n", "---\nBest filtered MRR on valid set:",
				bestValidScore);

		alpha_head = best_alpha_head;
		beta_head = best_beta_head;
		alpha_tail = best_alpha_tail;
		beta_tail = best_beta_tail;
		WuE = best_WuE;
		uEntity_vec = best_uEntity_vec;
		relation_vec = best_relation_vec;
		runRelationPrediction_Test(linkPredictionValues);
		fprintf(f2, "%s %.6lf %.6lf %.6lf %.6lf %.6lf\n", "RAW-test:",
				linkPredictionValues[0], linkPredictionValues[1],
				linkPredictionValues[2], linkPredictionValues[3],
				linkPredictionValues[4]);
		fprintf(f2, "%s %.6lf %.6lf %.6lf %.6lf %.6lf\n", "Filter-test:",
				linkPredictionValues[5], linkPredictionValues[6],
				linkPredictionValues[7], linkPredictionValues[8],
				linkPredictionValues[9]);
	}

	void optimizeWeights(FILE* f2) {

		for (int epoch = 0; epoch < nepoch; epoch++) {
			res = 0;
			aHead_tmp = alpha_head;
			bHead_tmp = beta_head;
			aTail_tmp = alpha_tail;
			bTail_tmp = beta_tail;
			WuE_tmp = WuE;
			computeExp();

			//vector<int> trainingIDs;
			for (int i = 0; i < fb_h.size(); ++i) {
				//	trainingIDs.push_back(i);
				//random_shuffle(trainingIDs.begin(), trainingIDs.end(),
				//		myrandom);
				//	for (std::vector<int>::iterator it = trainingIDs.begin();
				//		it != trainingIDs.end(); ++it) {
				//	int i = *it;
				//	//cout << i << endl;
				//	//int i=rand_max(fb_h.size());

				int head = fb_h[i], tail = fb_t[i], rel = fb_r[i];

				double pr = headTailSelector[rel];

				map<int, int> wEntities;
				map<string, map<int, int> > neiRelations;

				if (relGivenSample) {
					for (int index = 0; index < nneg; index++) {
						//int j = rand() % entity_num;
						if (rand() % 1000 < pr) {
							vector<int> tails = relTails[rel];
							int sizeT = tails.size();
							int j = tails[rand() % sizeT];
							int numSample = -1;
							while (triples[make_pair(head, rel)].count(j) > 0) {
								numSample++;
								if (numSample > sizeT)
									j = rand() % entity_num;
								else
									j = tails[rand() % sizeT];
							}
							train_kb_Mstep(head, tail, rel, j, true, wEntities,
									neiRelations);
							wEntities[j] += 1;
						} else {
							vector<int> heads = relHeads[rel];
							int sizeH = heads.size();
							int j = heads[rand() % sizeH];
							int numSample = -1;
							while (triples[make_pair(j, rel)].count(tail) > 0) {
								numSample++;
								if (numSample > sizeH)
									j = rand() % entity_num;
								else
									j = heads[rand() % sizeH];
							}
							train_kb_Mstep(head, tail, rel, j, false, wEntities,
									neiRelations);
							wEntities[j] += 1;
						}
					}
				} else {
					for (int index = 0; index < nneg; index++) {
						//int j = rand() % entity_num;
						if (rand() % 1000 < pr) {
							int j = rand() % entity_num;
							while (triples[make_pair(head, rel)].count(j) > 0)
								j = rand() % entity_num;
							train_kb_Mstep(head, tail, rel, j, true, wEntities,
									neiRelations);
							wEntities[j] += 1;
						} else {
							int j = rand() % entity_num;
							while (triples[make_pair(j, rel)].count(tail) > 0)
								j = rand() % entity_num;
							train_kb_Mstep(head, tail, rel, j, false, wEntities,
									neiRelations);
							wEntities[j] += 1;
						}
					}
				}

				if (rms)
					RMSProp_updateM(wEntities, rel, neiRelations);
				else
					AdaDelta_updateM(wEntities, rel, neiRelations);

				double temp = 0.0;
				for (int it = 0; it < relation_num; it++) {
					temp = aHead_tmp[rel][it];
					alpha_head[rel][it] = temp;
					exp_alpha_head[rel][it] = exp(temp);

					temp = bHead_tmp[rel][it];
					beta_head[rel][it] = temp;
					exp_beta_head[rel][it] = exp(temp);

					temp = aTail_tmp[rel][it];
					alpha_tail[rel][it] = temp;
					exp_alpha_tail[rel][it] = exp(temp);

					temp = bTail_tmp[rel][it];
					beta_tail[rel][it] = temp;
					exp_beta_tail[rel][it] = exp(temp);
				}

				for (map<int, int>::iterator it = wEntities.begin();
						it != wEntities.end(); ++it) {
					int id = it->first;
					WuE[id] = WuE_tmp[id];
					exp_WuE[id] = exp(WuE[id]);
				}

			}
			WuE = WuE_tmp;
			alpha_head = aHead_tmp;
			beta_head = bHead_tmp;
			alpha_tail = aTail_tmp;
			beta_tail = bTail_tmp;

			cout << "---\nepoch:" << epoch << "-> M (Train):  " << res << endl;

			//double heldOutloss = computeLossFuncHeldout();
			//cout << "-> M (Dev):  " << heldOutloss << endl;

			fprintf(f2, "%s %d %s %.6lf\n", "---\nepoch:", epoch,
					"-> M (Train):  ", res);
			//fprintf(f2, "%s %.6lf\n", "-> M (Dev):  ", heldOutloss);

			double validScore = runRelationPrediction_Dev();
			cout << "Filtered MRR on valid set: " << validScore << endl;
			//runLinkPrediction_Test();
			fprintf(f2, "%s %.6lf\n", "Filtered MRR on valid set:",
					validScore);
			//fprintf(f2, "%s %.6lf\n", "Accuracy on test set:", testRel);

			if (bestValidScore < validScore) {
				bestValidScore = validScore;
				//bestTestScore = testRel;
				best_alpha_head = alpha_head;
				best_beta_head = beta_head;
				best_alpha_tail = alpha_tail;
				best_beta_tail = beta_tail;
				best_WuE = WuE;
			}
		}

		cout << "---\nBest filtered MRR on valid set: " << bestValidScore
				<< endl;

		fprintf(f2, "%s %.6lf\n", "---\nBest filtered MRR on valid set:",
				bestValidScore);

		alpha_head = best_alpha_head;
		beta_head = best_beta_head;
		alpha_tail = best_alpha_tail;
		beta_tail = best_beta_tail;
		WuE = best_WuE;
		runRelationPrediction_Test(linkPredictionValues);
		fprintf(f2, "%s %.6lf %.6lf %.6lf %.6lf %.6lf\n", "RAW-test:",
				linkPredictionValues[0], linkPredictionValues[1],
				linkPredictionValues[2], linkPredictionValues[3],
				linkPredictionValues[4]);
		fprintf(f2, "%s %.6lf %.6lf %.6lf %.6lf %.6lf\n", "Filter-test:",
				linkPredictionValues[5], linkPredictionValues[6],
				linkPredictionValues[7], linkPredictionValues[8],
				linkPredictionValues[9]);
	}

	void optimizeVectors(FILE* f2) {
		for (int epoch = 0; epoch < nepoch; epoch++) {
			res = 0;

			relation_tmp = relation_vec;
			uEntity_tmp = uEntity_vec;

			//vector<int> trainingIDs;
			for (int i = 0; i < fb_h.size(); ++i) {
				//trainingIDs.push_back(i);
				//random_shuffle(trainingIDs.begin(), trainingIDs.end(),
				//		myrandom);
				//for (std::vector<int>::iterator it = trainingIDs.begin();
				//		it != trainingIDs.end(); ++it) {
				//	int i = *it;
				////cout << i << endl;
				////int i=rand_max(fb_h.size());

				int head = fb_h[i], tail = fb_t[i], rel = fb_r[i];

				double pr = headTailSelector[rel];

				map<int, int> entities, relations;

				if (relGivenSample) {
					for (int index = 0; index < nneg; index++) {
						//int j = rand() % entity_num;
						if (rand() % 1000 < pr) {
							vector<int> tails = relTails[rel];
							int sizeT = tails.size();
							int j = tails[rand() % sizeT];
							int numSample = -1;
							while (triples[make_pair(head, rel)].count(j) > 0) {
								numSample++;
								if (numSample > sizeT)
									j = rand() % entity_num;
								else
									j = tails[rand() % sizeT];
							}
							train_kb_Estep(head, tail, rel, j, true, entities,
									relations);
						} else {
							vector<int> heads = relHeads[rel];
							int sizeH = heads.size();
							int j = heads[rand() % sizeH];
							int numSample = -1;
							while (triples[make_pair(j, rel)].count(tail) > 0) {
								numSample++;
								if (numSample > sizeH)
									j = rand() % entity_num;
								else
									j = heads[rand() % sizeH];
							}
							train_kb_Estep(head, tail, rel, j, false, entities,
									relations);
						}
					}
				} else {
					for (int index = 0; index < nneg; index++) {
						if (rand() % 1000 < pr) {
							int j = rand() % entity_num;
							while (triples[make_pair(head, rel)].count(j) > 0)
								j = rand() % entity_num;
							train_kb_Estep(head, tail, rel, j, true, entities,
									relations);
						} else {
							int j = rand() % entity_num;
							while (triples[make_pair(j, rel)].count(tail) > 0)
								j = rand() % entity_num;
							train_kb_Estep(head, tail, rel, j, false, entities,
									relations);
						}
					}
				}

				if (rms)
					RMSProp_update(entities, relations);
				else
					AdaDelta_update(entities, relations);

				for (map<int, int>::iterator it = entities.begin();
						it != entities.end(); ++it) {
					int id = it->first;
					norm(uEntity_tmp[id]);
					uEntity_vec[id] = uEntity_tmp[id];
				}
				for (map<int, int>::iterator it = relations.begin();
						it != relations.end(); ++it) {
					int id = it->first;
					norm(relation_tmp[id]);
					relation_vec[id] = relation_tmp[id];
				}

			}

			relation_vec = relation_tmp;
			uEntity_vec = uEntity_tmp;

			cout << "---\nepoch:" << epoch << "-> E (Train):  " << res << endl;

			//double heldOutloss = computeLossFuncHeldout();
			//cout << "-> E (Dev): " << heldOutloss << endl;

			fprintf(f2, "%s %d %s %.6lf\n", "---\nepoch:", epoch,
					"-> E (Train):  ", res);
			//fprintf(f2, "%s %.6lf\n", "-> E (Dev):  ", heldOutloss);

			double validScore = runRelationPrediction_Dev();
			cout << "Filtered MRR on valid set: " << validScore << endl;
			//runLinkPrediction_Test();
			fprintf(f2, "%s %.6lf\n", "Filtered MRR on valid set:",
					validScore);
			//fprintf(f2, "%s %.6lf\n", "Accuracy on test set:", testRel);

			if (bestValidScore < validScore) {
				bestValidScore = validScore;
				//bestTestScore = testRel;
				best_uEntity_vec = uEntity_vec;
				best_relation_vec = relation_vec;
			}
		}

		cout << "---\nBest filtered MRR on valid set: " << bestValidScore
				<< endl;

		fprintf(f2, "%s %.6lf\n", "---\nBest filtered MRR on valid set:",
				bestValidScore);

		uEntity_vec = best_uEntity_vec;
		relation_vec = best_relation_vec;
		runRelationPrediction_Test(linkPredictionValues);
		fprintf(f2, "%s %.6lf %.6lf %.6lf %.6lf %.6lf\n", "RAW-test:",
				linkPredictionValues[0], linkPredictionValues[1],
				linkPredictionValues[2], linkPredictionValues[3],
				linkPredictionValues[4]);
		fprintf(f2, "%s %.6lf %.6lf %.6lf %.6lf %.6lf\n", "Filter-test:",
				linkPredictionValues[5], linkPredictionValues[6],
				linkPredictionValues[7], linkPredictionValues[8],
				linkPredictionValues[9]);
	}

	void write() {
		//ostringstream ss;
		//ss << ((iter + 1) * step);

		FILE* f2 = fopen((folder + suffix + ".relation2vec").c_str(), "w");
		FILE* f3 = fopen((folder + suffix + ".entity2vec").c_str(), "w");
		for (int i = 0; i < relation_num; i++) {
			for (int ii = 0; ii < n; ii++)
				fprintf(f2, "%.6lf\t", best_relation_vec[i][ii]); //round to 20 numbers after
			fprintf(f2, "\n");
		}
		for (int i = 0; i < entity_num; i++) {
			for (int ii = 0; ii < n; ii++)
				fprintf(f3, "%.6lf\t", best_uEntity_vec[i][ii]);
			fprintf(f3, "\n");
		}
		fclose(f2);
		fclose(f3);

		FILE* f0 = fopen((folder + suffix + ".Rweights").c_str(), "w");
		for (int i = 0; i < relation_num; i++) {
			for (int ii = 0; ii < relation_num; ii++)
				fprintf(f0, "%.6lf\t", best_alpha_head[i][ii]); //round to 20 numbers after
			fprintf(f0, "\n");
		}
		for (int i = 0; i < relation_num; i++) {
			for (int ii = 0; ii < relation_num; ii++)
				fprintf(f0, "%.6lf\t", best_beta_head[i][ii]); //round to 20 numbers after
			fprintf(f0, "\n");
		}

		for (int i = 0; i < relation_num; i++) {
			for (int ii = 0; ii < relation_num; ii++)
				fprintf(f0, "%.6lf\t", best_alpha_tail[i][ii]); //round to 20 numbers after
			fprintf(f0, "\n");
		}
		for (int i = 0; i < relation_num; i++) {
			for (int ii = 0; ii < relation_num; ii++)
				fprintf(f0, "%.6lf\t", best_beta_tail[i][ii]); //round to 20 numbers after
			fprintf(f0, "\n");
		}

		fclose(f0);

		FILE* f1 = fopen((folder + suffix + ".Eweights").c_str(), "w");
		for (int i = 0; i < entity_num; i++) {
			fprintf(f1, "%.6lf\t", best_WuE[i]); //round to 20 numbers after
			fprintf(f1, "\n");
		}
		fclose(f1);
	}

	void train_kb_Mstep(int head, int tail, int rel, int sampleEntity,
			bool isTail, map<int, int> &entities,
			map<string, map<int, int> > &neiRelations) {
		VectorXd disPos, disNeg, pos_headVec, pos_tailVec, neg_headVec,
				neg_tailVec;

//		double sum1 = calc_simValue(head, tail, rel, disPos);
//		double sum2;
//		if (isTail)
//			sum2 = calc_simValue(head, sampleEntity, rel, disNeg);
//		else
//			sum2 = calc_simValue(sampleEntity, tail, rel, disNeg);

		double pos_PFVHead = 0.0, pos_PFVTail = 0.0, neg_PFVHead = 0.0,
				neg_PFVTail = 0.0;

		double sum1 = calc_simValue(head, tail, rel, pos_PFVHead, pos_PFVTail,
				pos_headVec, pos_tailVec, disPos);
		double sum2;
		if (isTail)
			sum2 = calc_simValue(head, sampleEntity, rel, neg_PFVHead,
					neg_PFVTail, neg_headVec, neg_tailVec, disNeg);
		else
			sum2 = calc_simValue(sampleEntity, tail, rel, neg_PFVHead,
					neg_PFVTail, neg_headVec, neg_tailVec, disNeg);

		if (sum1 + margin > sum2) {
			res += margin + sum1 - sum2;
			computeGradientM(head, tail, rel, pos_PFVHead, pos_PFVTail,
					pos_headVec, pos_tailVec, disPos, 1, entities,
					neiRelations);
			if (isTail)
				computeGradientM(head, sampleEntity, rel, neg_PFVHead,
						neg_PFVTail, neg_headVec, neg_tailVec, disNeg, -1,
						entities, neiRelations);
			else
				computeGradientM(sampleEntity, tail, rel, neg_PFVHead,
						neg_PFVTail, neg_headVec, neg_tailVec, disNeg, -1,
						entities, neiRelations);
		}
	}

	void AdaDelta_updateM(map<int, int> entities, int rel,
			map<string, map<int, int> > neiRelations) {

		double delta;

		for (map<int, int>::iterator it = entities.begin();
				it != entities.end(); it++) {
			//Accumulate gradient
			int entityId = it->first;

			WuE_Eg[entityId] = 0.95 * WuE_Eg[entityId]
					+ 0.05 * WuE_grad[entityId] * WuE_grad[entityId];

			delta = (WuE_Edelta[entityId] + 1.0e-6)
					/ (WuE_Eg[entityId] + 1.0e-6);
			delta = sqrt(delta) * WuE_grad[entityId];

			WuE_Edelta[entityId] = 0.95 * WuE_Edelta[entityId]
					+ 0.05 * delta * delta;

			WuE_tmp[entityId] -= delta;

			WuE_grad[entityId] = 0;
		}

		if (ah) {
			map<int, int> relations = neiRelations["ah"];

			for (map<int, int>::iterator it = relations.begin();
					it != relations.end(); it++) {

				int relationId = it->first;

				aHead_Eg[rel][relationId] = 0.95 * aHead_Eg[rel][relationId]
						+ 0.05 * aHead_grad[rel][relationId]
								* aHead_grad[rel][relationId];

				delta = (aHead_Edelta[rel][relationId] + 1.0e-6)
						/ (aHead_Eg[rel][relationId] + 1.0e-6);
				delta = sqrt(delta) * aHead_grad[rel][relationId];

				aHead_Edelta[rel][relationId] = 0.95
						* aHead_Edelta[rel][relationId] + 0.05 * delta * delta;

				aHead_tmp[rel][relationId] -= delta;

				aHead_grad[rel][relationId] = 0;
			}
		}

		if (bh) {
			map<int, int> relations = neiRelations["bh"];

			for (map<int, int>::iterator it = relations.begin();
					it != relations.end(); it++) {

				int relationId = it->first;

				bHead_Eg[rel][relationId] = 0.95 * bHead_Eg[rel][relationId]
						+ 0.05 * bHead_grad[rel][relationId]
								* bHead_grad[rel][relationId];

				delta = (bHead_Edelta[rel][relationId] + 1.0e-6)
						/ (bHead_Eg[rel][relationId] + 1.0e-6);
				delta = sqrt(delta) * bHead_grad[rel][relationId];

				bHead_Edelta[rel][relationId] = 0.95
						* bHead_Edelta[rel][relationId] + 0.05 * delta * delta;

				bHead_tmp[rel][relationId] -= delta;

				bHead_grad[rel][relationId] = 0;
			}
		}

		if (at) {
			map<int, int> relations = neiRelations["at"];

			for (map<int, int>::iterator it = relations.begin();
					it != relations.end(); it++) {

				int relationId = it->first;

				aTail_Eg[rel][relationId] = 0.95 * aTail_Eg[rel][relationId]
						+ 0.05 * aTail_grad[rel][relationId]
								* aTail_grad[rel][relationId];

				delta = (aTail_Edelta[rel][relationId] + 1.0e-6)
						/ (aTail_Eg[rel][relationId] + 1.0e-6);
				delta = sqrt(delta) * aTail_grad[rel][relationId];

				aTail_Edelta[rel][relationId] = 0.95
						* aTail_Edelta[rel][relationId] + 0.05 * delta * delta;

				aTail_tmp[rel][relationId] -= delta;

				aTail_grad[rel][relationId] = 0;
			}
		}

		if (bt) {
			map<int, int> relations = neiRelations["bt"];

			for (map<int, int>::iterator it = relations.begin();
					it != relations.end(); it++) {

				int relationId = it->first;

				bTail_Eg[rel][relationId] = 0.95 * bTail_Eg[rel][relationId]
						+ 0.05 * bTail_grad[rel][relationId]
								* bTail_grad[rel][relationId];

				delta = (bTail_Edelta[rel][relationId] + 1.0e-6)
						/ (bTail_Eg[rel][relationId] + 1.0e-6);
				delta = sqrt(delta) * bTail_grad[rel][relationId];

				bTail_Edelta[rel][relationId] = 0.95
						* bTail_Edelta[rel][relationId] + 0.05 * delta * delta;

				bTail_tmp[rel][relationId] -= delta;

				bTail_grad[rel][relationId] = 0;
			}
		}
	}

	void RMSProp_updateM(map<int, int> entities, int rel,
			map<string, map<int, int> > neiRelations) {

		double delta;

		for (map<int, int>::iterator it = entities.begin();
				it != entities.end(); it++) {
			//Accumulate gradient
			int entityId = it->first;

			WuE_grad[entityId] += regularizer * WuE[entityId];

			WuE_Eg[entityId] = 0.9 * WuE_Eg[entityId]
					+ 0.1 * WuE_grad[entityId] * WuE_grad[entityId];

			delta = (WuE_Eg[entityId] + 1.0e-6);
			delta = rateW / sqrt(delta) * WuE_grad[entityId];

			WuE_tmp[entityId] -= delta;

			WuE_grad[entityId] = 0;
		}

		if (ah) {
			map<int, int> relations = neiRelations["ah"];

			for (map<int, int>::iterator it = relations.begin();
					it != relations.end(); it++) {

				int relationId = it->first;

				aHead_grad[rel][relationId] += regularizer
						* alpha_head[rel][relationId];

				aHead_Eg[rel][relationId] = 0.9 * aHead_Eg[rel][relationId]
						+ 0.1 * aHead_grad[rel][relationId]
								* aHead_grad[rel][relationId];

				delta = aHead_Eg[rel][relationId] + 1.0e-6;
				delta = rateW / sqrt(delta) * aHead_grad[rel][relationId];

				aHead_tmp[rel][relationId] -= delta;

				aHead_grad[rel][relationId] = 0;
			}
		}

		if (bh) {
			map<int, int> relations = neiRelations["bh"];

			for (map<int, int>::iterator it = relations.begin();
					it != relations.end(); it++) {

				int relationId = it->first;

				bHead_grad[rel][relationId] += regularizer
						* beta_head[rel][relationId];

				bHead_Eg[rel][relationId] = 0.9 * bHead_Eg[rel][relationId]
						+ 0.1 * bHead_grad[rel][relationId]
								* bHead_grad[rel][relationId];

				delta = bHead_Eg[rel][relationId] + 1.0e-6;
				delta = rateW / sqrt(delta) * bHead_grad[rel][relationId];

				bHead_tmp[rel][relationId] -= delta;

				bHead_grad[rel][relationId] = 0;
			}
		}

		if (at) {
			map<int, int> relations = neiRelations["at"];

			for (map<int, int>::iterator it = relations.begin();
					it != relations.end(); it++) {

				int relationId = it->first;

				aTail_grad[rel][relationId] += regularizer
						* alpha_tail[rel][relationId];

				aTail_Eg[rel][relationId] = 0.9 * aTail_Eg[rel][relationId]
						+ 0.1 * aTail_grad[rel][relationId]
								* aTail_grad[rel][relationId];

				delta = aTail_Eg[rel][relationId] + 1.0e-6;
				delta = rateW / sqrt(delta) * aTail_grad[rel][relationId];

				aTail_tmp[rel][relationId] -= delta;

				aTail_grad[rel][relationId] = 0;
			}
		}

		if (bt) {
			map<int, int> relations = neiRelations["bt"];

			for (map<int, int>::iterator it = relations.begin();
					it != relations.end(); it++) {

				int relationId = it->first;

				bTail_grad[rel][relationId] += regularizer
						* beta_tail[rel][relationId];

				bTail_Eg[rel][relationId] = 0.9 * bTail_Eg[rel][relationId]
						+ 0.1 * bTail_grad[rel][relationId]
								* bTail_grad[rel][relationId];

				delta = bTail_Eg[rel][relationId] + 1.0e-6;
				delta = rateW / sqrt(delta) * bTail_grad[rel][relationId];

				bTail_tmp[rel][relationId] -= delta;

				bTail_grad[rel][relationId] = 0;
			}
		}
	}

//	void countOccurTimes(int e1, int e2, int rel,
//			map<string, map<int, int> > &neiRelations) {
//		if (bh) {
//			map<int, int> neis = neiRelations["bh"];
//			vector<pair<int, int> > heads = KBgraph[e1]["head"];
//			for (int i = 0; i < heads.size(); i++) {
//				int r = heads[i].first;
//				int t = heads[i].second;
//				if ((r != rel) || (t != e2)) {
//					neis[r] += 1;
//				}
//			}
//			neiRelations["bh"] = neis;
//		}
//
//		if (ah) {
//			map<int, int> neis = neiRelations["ah"];
//			vector<pair<int, int> > tails = KBgraph[e1]["tail"];
//			for (int i = 0; i < tails.size(); i++) {
//				int r = tails[i].first;
//				neis[r] += 1;
//			}
//			neiRelations["ah"] = neis;
//		}
//
//		if (bt) {
//			map<int, int> neis = neiRelations["bt"];
//			vector<pair<int, int> > heads = KBgraph[e2]["head"];
//			for (int i = 0; i < heads.size(); i++) {
//				int r = heads[i].first;
//				neis[r] += 1;
//			}
//			neiRelations["bt"] = neis;
//		}
//
//		if (at) {
//			map<int, int> neis = neiRelations["at"];
//			vector<pair<int, int> > tails = KBgraph[e2]["tail"];
//			for (int i = 0; i < tails.size(); i++) {
//				int r = tails[i].first;
//				int h = tails[i].second;
//				if ((r != rel) || (h != e1)) {
//					neis[r] += 1;
//				}
//			}
//			neiRelations["at"] = neis;
//		}
//	}

	void computeGradientM(int e1, int e2, int rel, double PFVHead,
			double PFVTail, VectorXd headE1, VectorXd tailE2, VectorXd dis,
			int posneg, map<int, int> &entities,
			map<string, map<int, int> > &neiRelations) {

		VectorXd vecDer = 2 * dis;

		if (L1_flag) {
			for (int ii = 0; ii < n; ii++) {
				if (vecDer[ii] > 0)
					vecDer[ii] = 1;
				else if (vecDer[ii] < 0)
					vecDer[ii] = -1;
			}
		}

		vecDer = posneg * vecDer;

		entities[e1] += 1;
		entities[e2] += 1;
		double tmp = 0.0;

		tmp = exp(WuE[e1]) / PFVHead;
		WuE_grad[e1] += vecDer.dot(uEntity_vec[e1] - headE1) * tmp;

		tmp = exp(WuE[e2]) / PFVTail;
		WuE_grad[e2] -= vecDer.dot(uEntity_vec[e2] - tailE2) * tmp;

		if (bh) {
			map<int, int> neis = neiRelations["bh"];
			vector<pair<int, int> > heads = KBgraph[e1]["head"];
			for (int i = 0; i < heads.size(); i++) {
				int r = heads[i].first;
				int t = heads[i].second;
				if ((r != rel) || (t != e2)) {
					tmp = beta_head[rel][r];
					tmp = scale * exp(tmp) / PFVHead;
					bHead_grad[rel][r] += vecDer.dot(
							uEntity_vec[t] - relation_vec[r] - headE1) * tmp;
					neis[r] += 1;
				}
			}
			neiRelations["bh"] = neis;
		}

		if (ah) {
			map<int, int> neis = neiRelations["ah"];
			vector<pair<int, int> > tails = KBgraph[e1]["tail"];
			for (int i = 0; i < tails.size(); i++) {
				int r = tails[i].first;
				int h = tails[i].second;
				tmp = alpha_head[rel][r];
				tmp = scale * exp(tmp) / PFVHead;
				aHead_grad[rel][r] += vecDer.dot(
						uEntity_vec[h] + relation_vec[r] - headE1) * tmp;
				neis[r] += 1;
			}
			neiRelations["ah"] = neis;
		}

		if (bt) {
			map<int, int> neis = neiRelations["bt"];
			vector<pair<int, int> > heads = KBgraph[e2]["head"];
			for (int i = 0; i < heads.size(); i++) {
				int r = heads[i].first;
				int t = heads[i].second;
				tmp = beta_tail[rel][r];
				tmp = scale * exp(tmp) / PFVTail;
				bTail_grad[rel][r] -= vecDer.dot(
						uEntity_vec[t] - relation_vec[r] - tailE2) * tmp;
				neis[r] += 1;
			}
			neiRelations["bt"] = neis;
		}

		if (at) {
			map<int, int> neis = neiRelations["at"];
			vector<pair<int, int> > tails = KBgraph[e2]["tail"];
			for (int i = 0; i < tails.size(); i++) {
				int r = tails[i].first;
				int h = tails[i].second;
				if ((r != rel) || (h != e1)) {
					tmp = alpha_tail[rel][r];
					tmp = scale * exp(tmp) / PFVTail;
					aTail_grad[rel][r] -= vecDer.dot(
							uEntity_vec[h] + relation_vec[r] - tailE2) * tmp;
					neis[r] += 1;
				}
			}
			neiRelations["at"] = neis;
		}
	}

	void train_kb_Estep(int head, int tail, int rel, int sampleEntity,
			bool isTail, map<int, int> &entities, map<int, int> &relations) {
		VectorXd disPos, disNeg;
		double pos_PFVHead = 0.0, pos_PFVTail = 0.0, neg_PFVHead = 0.0,
				neg_PFVTail = 0.0;

		double sum1 = calc_simValue(head, tail, rel, pos_PFVHead, pos_PFVTail,
				disPos);
		double sum2;
		if (isTail)
			sum2 = calc_simValue(head, sampleEntity, rel, neg_PFVHead,
					neg_PFVTail, disNeg);
		else
			sum2 = calc_simValue(sampleEntity, tail, rel, neg_PFVHead,
					neg_PFVTail, disNeg);

		if (sum1 + margin > sum2) {
			res += margin + sum1 - sum2;
			map<int, int> localEntities, localRelations;
			computeGradient(head, tail, rel, pos_PFVHead, pos_PFVTail, disPos,
					1, localEntities, localRelations);
			if (isTail)
				computeGradient(head, sampleEntity, rel, neg_PFVHead,
						neg_PFVTail, disNeg, -1, localEntities, localRelations);
			else
				computeGradient(sampleEntity, tail, rel, neg_PFVHead,
						neg_PFVTail, disNeg, -1, localEntities, localRelations);

			for (map<int, int>::iterator it = localEntities.begin();
					it != localEntities.end(); ++it) {
				entities[it->first] += 1;
			}
			for (map<int, int>::iterator it = localRelations.begin();
					it != localRelations.end(); ++it) {
				relations[it->first] += 1;
			}
		}
	}

	void AdaDelta_update(map<int, int> entities, map<int, int> relations) { //isTail: sampleEntity is tail of the incorrect triple?

		VectorXd delta;

		for (map<int, int>::iterator it = entities.begin();
				it != entities.end(); it++) {
			//Accumulate gradient
			int entityId = it->first;

			enEg[entityId] = 0.95 * enEg[entityId].array()
					+ 0.05 * (uEntity_grad[entityId].array().square());
			//Compute Update
			delta = ((enEdelta[entityId].array() + 1.0e-6)
					/ (enEg[entityId].array() + 1.0e-6));
			delta = delta.array().sqrt();
			delta = delta.array() * uEntity_grad[entityId].array();

			//Accumulate update:
			enEdelta[entityId] = 0.95 * enEdelta[entityId].array()
					+ 0.05 * (delta.array().square());

			//Apply update:
			uEntity_tmp[entityId] -= delta;

			uEntity_grad[entityId].setZero();

			//norm(uEntity_vec[entityId] );
		}

		for (map<int, int>::iterator it = relations.begin();
				it != relations.end(); it++) {
			int relationId = it->first;

			relEg[relationId] = 0.95 * relEg[relationId].array()
					+ 0.05 * (relation_grad[relationId].array().square());

			delta = ((relEdelta[relationId].array() + 1.0e-6)
					/ (relEg[relationId].array() + 1.0e-6));
			delta = delta.array().sqrt();
			delta = delta.array() * relation_grad[relationId].array();

			relEdelta[relationId] = 0.95 * relEdelta[relationId].array()
					+ 0.05 * (delta.array().square());

			relation_tmp[relationId] -= delta;

			relation_grad[relationId].setZero();

			//norm(relation_vec[relationId]);
		}

	}

	void RMSProp_update(map<int, int> entities, map<int, int> relations) { //isTail: sampleEntity is tail of the incorrect triple?

		VectorXd delta;

		for (map<int, int>::iterator it = entities.begin();
				it != entities.end(); it++) {
			//Accumulate gradient
			int entityId = it->first;

			enEg[entityId] = 0.9 * enEg[entityId].array()
					+ 0.1 * (uEntity_grad[entityId].array().square());
			//Compute Update
			delta = enEg[entityId].array() + 1.0e-6;
			delta = delta.array().sqrt();
			delta = rate * uEntity_grad[entityId].cwiseQuotient(delta);

			//Apply update:
			uEntity_tmp[entityId] -= delta;

			uEntity_grad[entityId].setZero();

			//norm(uEntity_vec[entityId] );
		}

		for (map<int, int>::iterator it = relations.begin();
				it != relations.end(); it++) {
			int relationId = it->first;

			relEg[relationId] = 0.9 * relEg[relationId].array()
					+ 0.1 * (relation_grad[relationId].array().square());

			delta = relEg[relationId].array() + 1.0e-6;
			delta = delta.array().sqrt();
			delta = rate * relation_grad[relationId].cwiseQuotient(delta);

			relation_tmp[relationId] -= delta;

			relation_grad[relationId].setZero();

			//norm(relation_vec[relationId]);
		}

	}

	void computeGradient(int e1, int e2, int rel, double PFVHead,
			double PFVTail, VectorXd dis, int posneg, map<int, int> &entities,
			map<int, int> &relations) {

		VectorXd vecDer = 2 * dis;

		if (L1_flag) {
			for (int ii = 0; ii < n; ii++) {
				if (vecDer[ii] > 0)
					vecDer[ii] = 1;
				else if (vecDer[ii] < 0)
					vecDer[ii] = -1;
			}
		}

		vecDer = posneg * vecDer;

		relation_grad[rel] += vecDer;

		entities[e1] += 1;
		entities[e2] += 1;
		relations[rel] += 1;

		double temp = 0.0;

		if (bh) {
			vector<pair<int, int> > heads = KBgraph[e1]["head"];
			for (int i = 0; i < heads.size(); i++) {
				int r = heads[i].first;
				int t = heads[i].second;
				if ((r != rel) || (t != e2)) {
					temp = scale * exp_beta_head[rel][r] / PFVHead;
					uEntity_grad[t] += temp * vecDer;
					relation_grad[r] -= temp * vecDer;
				}
				entities[t] += 1;
				relations[r] += 1;
			}
		}

		if (ah) {
			vector<pair<int, int> > tails = KBgraph[e1]["tail"];
			for (int i = 0; i < tails.size(); i++) {
				int r = tails[i].first;
				int h = tails[i].second;
				temp = scale * exp_alpha_head[rel][r] / PFVHead;
				uEntity_grad[h] += temp * vecDer;
				relation_grad[r] += temp * vecDer;

				entities[h] += 1;
				relations[r] += 1;
			}
		}

		uEntity_grad[e1] += (dscale + exp_WuE[e1]) / PFVHead * vecDer;

		if (bt) {
			vector<pair<int, int> > heads = KBgraph[e2]["head"];
			for (int i = 0; i < heads.size(); i++) {
				int r = heads[i].first;
				int t = heads[i].second;
				temp = scale * exp_beta_tail[rel][r] / PFVTail;
				uEntity_grad[t] -= temp * vecDer;
				relation_grad[r] += temp * vecDer;
				entities[t] += 1;
				relations[r] += 1;
			}
		}

		if (at) {
			vector<pair<int, int> > tails = KBgraph[e2]["tail"];
			for (int i = 0; i < tails.size(); i++) {
				int r = tails[i].first;
				int h = tails[i].second;
				if ((r != rel) || (h != e1)) {
					temp = scale * exp_alpha_tail[rel][r] / PFVTail;
					uEntity_grad[h] -= temp * vecDer;
					relation_grad[r] -= temp * vecDer;

				}
				entities[h] += 1;
				relations[r] += 1;
			}
		}

		uEntity_grad[e2] -= (dscale + exp_WuE[e2]) / PFVTail * vecDer;

	}

	double calc_simValue(int e1, int e2, int rel, double &partFuncValHead,
			double &partFuncValTail, VectorXd &distanceVec) {
		VectorXd sim = getHeadVector(e1, e2, rel, partFuncValHead)
				+ relation_vec[rel]
				- getTailVector(e1, e2, rel, partFuncValTail);
		//VectorXd sim = uEntity_vec[e1] + relation_vec[rel] - uEntity_vec[e2];

		distanceVec = sim;
		if (L1_flag)
			return sim.lpNorm<1>();
		else
			return sim.squaredNorm();
	}

	double calc_simValue(int e1, int e2, int rel, double &partFuncValHead,
			double &partFuncValTail, VectorXd &headVec, VectorXd &tailVec,
			VectorXd &distanceVec) {
		headVec = getHeadVector(e1, e2, rel, partFuncValHead);
		tailVec = getTailVector(e1, e2, rel, partFuncValTail);
		VectorXd sim = headVec + relation_vec[rel] - tailVec;
		//VectorXd sim = uEntity_vec[e1] + relation_vec[rel] - uEntity_vec[e2];

		distanceVec = sim;
		if (L1_flag)
			return sim.lpNorm<1>();
		else
			return sim.squaredNorm();
	}

	double calc_simValue(int e1, int e2, int rel, VectorXd &headVec,
			VectorXd &tailVec, VectorXd &distanceVec) {
		headVec = getHeadVector(e1, e2, rel);
		tailVec = getTailVector(e1, e2, rel);
		VectorXd sim = headVec + relation_vec[rel] - tailVec;
		//VectorXd sim = uEntity_vec[e1] + relation_vec[rel] - uEntity_vec[e2];

		distanceVec = sim;
		if (L1_flag)
			return sim.lpNorm<1>();
		else
			return sim.squaredNorm();
	}

	double calc_simValue(int e1, int e2, int rel, VectorXd &distanceVec) {
		VectorXd sim = getHeadVector(e1, e2, rel) + relation_vec[rel]
				- getTailVector(e1, e2, rel);
		//VectorXd sim = uEntity_vec[e1] + relation_vec[rel] - uEntity_vec[e2];

		distanceVec = sim;
		if (L1_flag)
			return sim.lpNorm<1>();
		else
			return sim.squaredNorm();
	}

	double calc_simValue(int e1, int e2, int rel) {
		VectorXd sim = getHeadVector(e1, e2, rel) + relation_vec[rel]
				- getTailVector(e1, e2, rel);
		if (L1_flag)
			return sim.lpNorm<1>();
		else
			return sim.squaredNorm();
	}

//	double calc_sim(int e1, int e2, int rel) {
//		VectorXd sim = uEntity_vec[e1] + relation_vec[rel] - uEntity_vec[e2];
//		if (L1_flag)
//			return sim.lpNorm<1>();
//		else
//			return sim.squaredNorm();
//	}

	void computeGradientM(int e1, int e2, int rel, double PFVHead,
			double PFVTail, VectorXd headE1, VectorXd tailE2, VectorXd dis,
			int posneg) {

		VectorXd vecDer = 2 * dis;

		if (L1_flag) {
			for (int ii = 0; ii < n; ii++) {
				if (vecDer[ii] > 0)
					vecDer[ii] = 1;
				else if (vecDer[ii] < 0)
					vecDer[ii] = -1;
			}
		}

		vecDer = posneg * vecDer;

		double tmp = 0.0;

		tmp = exp(WuE[e1]) / PFVHead;
		WuE_grad[e1] += vecDer.dot(uEntity_vec[e1] - headE1) * tmp;

		tmp = exp(WuE[e2]) / PFVTail;
		WuE_grad[e2] -= vecDer.dot(uEntity_vec[e2] - tailE2) * tmp;

		if (bh) {
			vector<pair<int, int> > heads = KBgraph[e1]["head"];
			for (int i = 0; i < heads.size(); i++) {
				int r = heads[i].first;
				int t = heads[i].second;
				if ((r != rel) || (t != e2)) {
					tmp = beta_head[rel][r];
					tmp = scale * exp(tmp) / PFVHead;
					bHead_grad[rel][r] += vecDer.dot(
							uEntity_vec[t] - relation_vec[r] - headE1) * tmp;

				}
			}

		}

		if (ah) {
			vector<pair<int, int> > tails = KBgraph[e1]["tail"];
			for (int i = 0; i < tails.size(); i++) {
				int r = tails[i].first;
				int h = tails[i].second;
				tmp = alpha_head[rel][r];
				tmp = scale * exp(tmp) / PFVHead;
				aHead_grad[rel][r] += vecDer.dot(
						uEntity_vec[h] + relation_vec[r] - headE1) * tmp;

			}

		}

		if (bt) {
			vector<pair<int, int> > heads = KBgraph[e2]["head"];
			for (int i = 0; i < heads.size(); i++) {
				int r = heads[i].first;
				int t = heads[i].second;
				tmp = beta_tail[rel][r];
				tmp = scale * exp(tmp) / PFVTail;
				bTail_grad[rel][r] -= vecDer.dot(
						uEntity_vec[t] - relation_vec[r] - tailE2) * tmp;

			}

		}

		if (at) {
			vector<pair<int, int> > tails = KBgraph[e2]["tail"];
			for (int i = 0; i < tails.size(); i++) {
				int r = tails[i].first;
				int h = tails[i].second;
				if ((r != rel) || (h != e1)) {
					tmp = alpha_tail[rel][r];
					tmp = scale * exp(tmp) / PFVTail;
					aTail_grad[rel][r] -= vecDer.dot(
							uEntity_vec[h] + relation_vec[r] - tailE2) * tmp;

				}
			}

		}
	}

	void computeGradient(int e1, int e2, int rel, double PFVHead,
			double PFVTail, VectorXd dis, int posneg) {

		VectorXd vecDer = 2 * dis;

		if (L1_flag) {
			for (int ii = 0; ii < n; ii++) {
				if (vecDer[ii] > 0)
					vecDer[ii] = 1;
				else if (vecDer[ii] < 0)
					vecDer[ii] = -1;
			}
		}

		vecDer = posneg * vecDer;

		relation_grad[rel] += vecDer;

		double temp = 0.0;

		if (bh) {
			vector<pair<int, int> > heads = KBgraph[e1]["head"];
			for (int i = 0; i < heads.size(); i++) {
				int r = heads[i].first;
				int t = heads[i].second;
				if ((r != rel) || (t != e2)) {
					temp = scale * exp_beta_head[rel][r] / PFVHead;
					uEntity_grad[t] += temp * vecDer;
					relation_grad[r] -= temp * vecDer;
				}
			}
		}

		if (ah) {
			vector<pair<int, int> > tails = KBgraph[e1]["tail"];
			for (int i = 0; i < tails.size(); i++) {
				int r = tails[i].first;
				int h = tails[i].second;
				temp = scale * exp_alpha_head[rel][r] / PFVHead;
				uEntity_grad[h] += temp * vecDer;
				relation_grad[r] += temp * vecDer;
			}
		}

		uEntity_grad[e1] += (dscale + exp_WuE[e1]) / PFVHead * vecDer;

		if (bt) {
			vector<pair<int, int> > heads = KBgraph[e2]["head"];
			for (int i = 0; i < heads.size(); i++) {
				int r = heads[i].first;
				int t = heads[i].second;
				temp = scale * exp_beta_tail[rel][r] / PFVTail;
				uEntity_grad[t] -= temp * vecDer;
				relation_grad[r] += temp * vecDer;
			}
		}

		if (at) {
			vector<pair<int, int> > tails = KBgraph[e2]["tail"];
			for (int i = 0; i < tails.size(); i++) {
				int r = tails[i].first;
				int h = tails[i].second;
				if ((r != rel) || (h != e1)) {
					temp = scale * exp_alpha_tail[rel][r] / PFVTail;
					uEntity_grad[h] -= temp * vecDer;
					relation_grad[r] -= temp * vecDer;

				}
			}
		}

		uEntity_grad[e2] -= (dscale + exp_WuE[e2]) / PFVTail * vecDer;

	}

	void computeExp() {

		for (int i = 0; i < WuE.size(); i++) {
			exp_WuE[i] = exp(WuE[i]);
		}

		double temp = 0.0;
		for (int i = 0; i < relation_num; i++)
			for (int j = 0; j < relation_num; j++) {
				if (ah) {
					temp = alpha_head[i][j];
					exp_alpha_head[i][j] = exp(temp);
				}
				if (bh) {
					temp = beta_head[i][j];
					exp_beta_head[i][j] = exp(temp);
				}
				if (at) {
					temp = alpha_tail[i][j];
					exp_alpha_tail[i][j] = exp(temp);
				}
				if (bt) {
					temp = beta_tail[i][j];
					exp_beta_tail[i][j] = exp(temp);
				}
			}
	}

	VectorXd getHeadVector(int head, int tail, int rel) {
		VectorXd headVec;
		headVec.setZero(n);

		double partFuncValue = 0.0;

		if (bh) {
			vector<pair<int, int> > heads = KBgraph[head]["head"];
			for (int i = 0; i < heads.size(); i++) {
				int r = heads[i].first;
				int t = heads[i].second;
				if ((r != rel) || (t != tail)) {
					headVec += exp_beta_head[rel][r]
							* (uEntity_vec[t] - relation_vec[r]);
					partFuncValue += exp_beta_head[rel][r];
				}
			}
		}

		if (ah) {
			vector<pair<int, int> > tails = KBgraph[head]["tail"];
			for (int i = 0; i < tails.size(); i++) {
				int r = tails[i].first;
				int h = tails[i].second;
				headVec += exp_alpha_head[rel][r]
						* (uEntity_vec[h] + relation_vec[r]);
				partFuncValue += exp_alpha_head[rel][r];
			}
		}

		headVec = scale * headVec;
		partFuncValue = scale * partFuncValue;

		headVec += (dscale + exp_WuE[head]) * uEntity_vec[head];

		partFuncValue += dscale + exp_WuE[head];

		headVec = headVec / partFuncValue;

		return headVec;
	}

	VectorXd getTailVector(int head, int tail, int rel) {
		VectorXd tailVec;
		tailVec.setZero(n);

		double partFuncValue = 0.0;

		if (bt) {
			vector<pair<int, int> > heads = KBgraph[tail]["head"];
			for (int i = 0; i < heads.size(); i++) {
				int r = heads[i].first;
				int t = heads[i].second;
				tailVec += exp_beta_tail[rel][r]
						* (uEntity_vec[t] - relation_vec[r]);
				partFuncValue += exp_beta_tail[rel][r];
			}
		}

		if (at) {
			vector<pair<int, int> > tails = KBgraph[tail]["tail"];
			for (int i = 0; i < tails.size(); i++) {
				int r = tails[i].first;
				int h = tails[i].second;
				if ((r != rel) || (h != head)) {
					tailVec += exp_alpha_tail[rel][r]
							* (uEntity_vec[h] + relation_vec[r]);
					partFuncValue += exp_alpha_tail[rel][r];
				}

			}
		}

		tailVec = scale * tailVec;
		partFuncValue = scale * partFuncValue;

		tailVec += (dscale + exp_WuE[tail]) * uEntity_vec[tail];

		partFuncValue += dscale + exp_WuE[tail];

		tailVec = tailVec / partFuncValue;

		return tailVec;
	}

	VectorXd getHeadVector(int head, int tail, int rel, double &partFuncValue) {
		VectorXd headVec;
		headVec.setZero(n);

		partFuncValue = 0.0;

		if (bh) {
			vector<pair<int, int> > heads = KBgraph[head]["head"];
			for (int i = 0; i < heads.size(); i++) {
				int r = heads[i].first;
				int t = heads[i].second;
				if ((r != rel) || (t != tail)) {
					headVec += exp_beta_head[rel][r]
							* (uEntity_vec[t] - relation_vec[r]);
					partFuncValue += exp_beta_head[rel][r];
				}
			}
		}

		if (ah) {
			vector<pair<int, int> > tails = KBgraph[head]["tail"];
			for (int i = 0; i < tails.size(); i++) {
				int r = tails[i].first;
				int h = tails[i].second;
				headVec += exp_alpha_head[rel][r]
						* (uEntity_vec[h] + relation_vec[r]);
				partFuncValue += exp_alpha_head[rel][r];
			}
		}

		headVec = scale * headVec;
		partFuncValue = scale * partFuncValue;

		headVec += (dscale + exp_WuE[head]) * uEntity_vec[head];

		partFuncValue += dscale + exp_WuE[head];

		headVec = headVec / partFuncValue;

		return headVec;
	}

	VectorXd getTailVector(int head, int tail, int rel, double &partFuncValue) {
		VectorXd tailVec;
		tailVec.setZero(n);

		partFuncValue = 0.0;

		if (bt) {
			vector<pair<int, int> > heads = KBgraph[tail]["head"];
			for (int i = 0; i < heads.size(); i++) {
				int r = heads[i].first;
				int t = heads[i].second;
				tailVec += exp_beta_tail[rel][r]
						* (uEntity_vec[t] - relation_vec[r]);
				partFuncValue += exp_beta_tail[rel][r];
			}
		}

		if (at) {
			vector<pair<int, int> > tails = KBgraph[tail]["tail"];
			for (int i = 0; i < tails.size(); i++) {
				int r = tails[i].first;
				int h = tails[i].second;
				if ((r != rel) || (h != head)) {
					tailVec += exp_alpha_tail[rel][r]
							* (uEntity_vec[h] + relation_vec[r]);
					partFuncValue += exp_alpha_tail[rel][r];
				}

			}
		}

		tailVec = scale * tailVec;
		partFuncValue = scale * partFuncValue;

		tailVec += (dscale + exp_WuE[tail]) * uEntity_vec[tail];

		partFuncValue += dscale + exp_WuE[tail];

		tailVec = tailVec / partFuncValue;

		return tailVec;
	}

//	VectorXd getHeadVector(int head, int tail, int rel, bool isTmp) {
//		VectorXd headVec;
//
//		headVec.setZero(n);
//
//		double sum = 0.0;
//
//		vector<pair<int, int> > heads = KBgraph[head]["head"], tails =
//				KBgraph[head]["tail"];
//		for (int i = 0; i < heads.size(); i++) {
//			int r = heads[i].first;
//			int t = heads[i].second;
//			if ((r != rel) || (t != tail)) {
//				if (isTmp)
//					headVec += beta_head[rel][r]
//							* (uEntity_tmp[t] - relation_tmp[r]);
//				else
//					headVec += beta_head[rel][r]
//							* (uEntity_vec[t] - relation_vec[r]);
//
//				sum += beta_head[rel][r];
//			}
//		}
//		for (int i = 0; i < tails.size(); i++) {
//			int r = tails[i].first;
//			int h = tails[i].second;
//			if (isTmp)
//				headVec += alpha_head[rel][r]
//						* (uEntity_tmp[h] + relation_tmp[r]);
//			else
//				headVec += alpha_head[rel][r]
//						* (uEntity_vec[h] + relation_vec[r]);
//
//			sum += alpha_head[rel][r];
//		}
//
//		if (isTmp)
//			headVec += (1 - sum) * uEntity_tmp[head];
//		else {
//			headVec += (1 - sum) * uEntity_vec[head];
//		}
//
//		return headVec;
//	}
//
//	VectorXd getTailVector(int head, int tail, int rel, bool isTmp) {
//		VectorXd tailVec;
//		tailVec.setZero(n);
//
//		vector<pair<int, int> > heads = KBgraph[tail]["head"], tails =
//				KBgraph[tail]["tail"];
//
//		double sum = 0.0;
//
//		for (int i = 0; i < heads.size(); i++) {
//			int r = heads[i].first;
//			int t = heads[i].second;
//			if (isTmp)
//				tailVec += beta_tail[rel][r]
//						* (uEntity_tmp[t] - relation_tmp[r]);
//			else
//				tailVec += beta_tail[rel][r]
//						* (uEntity_vec[t] - relation_vec[r]);
//
//			sum += beta_tail[rel][r];
//		}
//		for (int i = 0; i < tails.size(); i++) {
//			int r = tails[i].first;
//			int h = tails[i].second;
//			if ((r != rel) || (h != head)) {
//				if (isTmp)
//					tailVec += alpha_tail[rel][r]
//							* (uEntity_tmp[h] + relation_tmp[r]);
//				else
//					tailVec += alpha_tail[rel][r]
//							* (uEntity_vec[h] + relation_vec[r]);
//
//				sum += alpha_tail[rel][r];
//			}
//
//		}
//
//		if (isTmp) {
//			tailVec += (1 - sum) * uEntity_tmp[tail];
//		} else
//			tailVec += (1 - sum) * uEntity_vec[tail];
//
//		return tailVec;
//	}

//Optimize both alpha, beta and vectors...

//	double computeLossFuncHeldout() {
//		double lostF = 0.0;
//		for (int testid = 0; testid < dev_fb_t.size() - 1; testid += 2) {
//			int h = dev_fb_h[testid];
//			int l = dev_fb_t[testid];
//			int rel = dev_fb_r[testid];
//			double pos_Sim = calc_simValue(h, l, rel);
//			if (h != dev_fb_h[testid + 1] or rel != dev_fb_r[testid + 1]) {
//				cout << testid << "something not correct with development set"
//						<< endl;
//				return 0.0;
//			}
//
//			l = dev_fb_t[testid + 1];
//
//			double neg_Sim = calc_simValue(h, l, rel);
//
//			if (pos_Sim + margin > neg_Sim) {
//				lostF += pos_Sim + margin - neg_Sim;
//			}
//		}
//		return lostF;
//	}

	double evalRelationPrediction_Dev(int start, int end) {

		double MR = 0, H10 = 0, H1 = 0, H5 = 0, MRR = 0;

		double filter_MR = 0, filter_H10 = 0, filter_H1 = 0, filter_H5 = 0,
				filter_MRR = 0;

		for (int validid = start; validid < end; validid++) {
			//cout << validid << endl;

			int head = dev_fb_h[validid];
			int tail = dev_fb_t[validid];
			int rel = dev_fb_r[validid];
			vector<pair<int, double> > scores;
			for (int i = 0; i < relation_num; i++) {
				double sim = calc_simValue(head, tail, i);
				scores.push_back(make_pair(i, sim));
			}
			sort(scores.begin(), scores.end(), cmp);

			int filter = 0;
			for (int i = 0; i < scores.size(); i++) {

				if ((triples[make_pair(head, scores[i].first)].count(tail) == 0)
						&& (dev_test_triples[make_pair(head, scores[i].first)].count(
								tail) == 0))
					filter += 1;

				if (scores[i].first == rel) {

					MR += (i + 1);
					MRR += 1.0 / (i + 1);
					if (i == 0)
						H1 += 1;
					if (i < 5)
						H5 += 1;
					if (i < 10)
						H10 += 1;

					filter_MR += (filter + 1);
					filter_MRR += 1.0 / (filter + 1);
					if (filter == 0)
						filter_H1 += 1;
					if (filter < 5)
						filter_H5 += 1;
					if (filter < 10)
						filter_H10 += 1;

					break;
				}
			}
			scores.clear();
		}

		double dev_size = 1.0 * dev_fb_h.size();

//		cout << "RAW => MR: " << (MR / dev_size) << ",\tMRR: "
//				<< (MRR / dev_size) << ",\t H@1: " << (H1 / dev_size)
//				<< ",\t H@5: " << (H5 / dev_size) << ",\t H@10: "
//				<< (H10 / dev_size) << endl;
//
//		cout << "Filter => MR: " << (filter_MR / dev_size) << ",\tMRR: "
//				<< (filter_MRR / dev_size) << ",\t H@1: "
//				<< (filter_H1 / dev_size) << ",\t H@5: "
//				<< (filter_H5 / dev_size) << ",\t H@10: "
//				<< (filter_H10 / dev_size) << endl;

		return (filter_MRR) / (dev_size);

	}

	double runRelationPrediction_Dev() {

		double result = 0.0;

		int size = dev_fb_h.size();
		int stepsize = size / nThreads;

		//cout << size << " " << nThreads << " " << stepsize << endl;

#pragma omp parallel for num_threads(nThreads) reduction(+:result)
		for (int i = 0; i < nThreads; i++) {
			int start = i * stepsize;
			int end = (i + 1) * stepsize;
			result += evalRelationPrediction_Dev(start, end);
		}

		result += evalRelationPrediction_Dev(nThreads * stepsize, size);

		return result;

	}

	void runRelationPrediction_Test(vector<double> &values1) {

		vector<double> values;
		for (int i = 0; i < 10; i++)
			values.push_back(0.0);

		int size = test_fb_h.size();
		int stepsize = size / nThreads;
		map<int, vector<double> > results;

#pragma omp parallel for num_threads(nThreads)
		for (int i = 0; i < nThreads; i++) {
			int start = i * stepsize;
			int end = (i + 1) * stepsize;
			results[i] = evalRelationPrediction_Test(start, end);
		}

		results[nThreads] = evalRelationPrediction_Test(nThreads * stepsize,
				size);

		for (map<int, vector<double> >::iterator it = results.begin();
				it != results.end(); it++) {
			vector<double> temp = it->second;
			for (int i = 0; i < 10; i++)
				values[i] += temp[i];
		}

		values1 = values;
	}

	vector<double> evalRelationPrediction_Test(int start, int end) {

		vector<double> values;
		for (int i = 0; i < 10; i++)
			values.push_back(0.0);

		double MR = 0, H10 = 0, H1 = 0, H5 = 0, MRR = 0;

		double filter_MR = 0, filter_H10 = 0, filter_H1 = 0, filter_H5 = 0,
				filter_MRR = 0;

		for (int validid = start; validid < end; validid++) {
			//cout << validid << endl;

			int head = test_fb_h[validid];
			int tail = test_fb_t[validid];
			int rel = test_fb_r[validid];
			vector<pair<int, double> > scores;
			for (int i = 0; i < relation_num; i++) {
				double sim = calc_simValue(head, tail, i);
				scores.push_back(make_pair(i, sim));
			}
			sort(scores.begin(), scores.end(), cmp);

			int filter = 0;
			for (int i = 0; i < scores.size(); i++) {

				if ((triples[make_pair(head, scores[i].first)].count(tail) == 0)
						&& (dev_test_triples[make_pair(head, scores[i].first)].count(
								tail) == 0))
					filter += 1;

				if (scores[i].first == rel) {

					MR += (i + 1);
					MRR += 1.0 / (i + 1);
					if (i == 0)
						H1 += 1;
					if (i < 5)
						H5 += 1;
					if (i < 10)
						H10 += 1;

					filter_MR += (filter + 1);
					filter_MRR += 1.0 / (filter + 1);
					if (filter == 0)
						filter_H1 += 1;
					if (filter < 5)
						filter_H5 += 1;
					if (filter < 10)
						filter_H10 += 1;

					break;
				}
			}
			scores.clear();

		}

		double dev_size = 1.0 * test_fb_h.size();

//				cout << "RAW => MR: " << (MR / dev_size) << ",\tMRR: "
//						<< (MRR / dev_size) << ",\t H@1: " << (H1 / dev_size)
//						<< ",\t H@5: " << (H5 / dev_size) << ",\t H@10: "
//						<< (H10 / dev_size) << endl;

		values[0] = MR / dev_size;
		values[1] = MRR / dev_size;
		values[2] = H1 / dev_size;
		values[3] = H5 / dev_size;
		values[4] = H10 / dev_size;

//				cout << "Filter => MR: " << (filter_MR / dev_size) << ",\tMRR: "
//						<< (filter_MRR / dev_size) << ",\t H@1: "
//						<< (filter_H1 / dev_size) << ",\t H@5: "
//						<< (filter_H5 / dev_size) << ",\t H@10: "
//						<< (filter_H10 / dev_size) << endl;

		values[5] = filter_MR / dev_size;
		values[6] = filter_MRR / dev_size;
		values[7] = filter_H1 / dev_size;
		values[8] = filter_H5 / dev_size;
		values[9] = filter_H10 / dev_size;

		return values;

	}
}
;

Train train;
void prepare(string folder) {
	FILE* f1 = fopen((folder + "entity2id.txt").c_str(), "r");
	FILE* f2 = fopen((folder + "relation2id.txt").c_str(), "r");
	int x;
	while (fscanf(f1, "%s%d", buf, &x) == 2) {
		string st = buf;
		entity2id[st] = x;
		id2entity[x] = st;
		entity_num++;
	}
	while (fscanf(f2, "%s%d", buf, &x) == 2) {
		string st = buf;
		relation2id[st] = x;
		id2relation[x] = st;
		relation_num++;
	}
	FILE* f_kb = fopen((folder + "train.txt").c_str(), "r");
	while (fscanf(f_kb, "%s", buf) == 1) {
		string s1 = buf; //left entity

		fscanf(f_kb, "%s", buf);
		string s3 = buf;	//relation

		fscanf(f_kb, "%s", buf);
		string s2 = buf;	//right entity

		if (entity2id.count(s1) == 0) {
			cout << "miss entity:" << s1 << endl;
		}
		if (entity2id.count(s2) == 0) {
			cout << "miss entity:" << s2 << endl;
		}
		if (relation2id.count(s3) == 0) {
			cout << "miss relation:" << s3 << endl;
			relation2id[s3] = relation_num;
			relation_num++;
		}
		left_entity[relation2id[s3]][entity2id[s1]]++;

		right_entity[relation2id[s3]][entity2id[s2]]++;

//Input: left/head entity, right/tail entity, relation
		train.add(entity2id[s1], entity2id[s2], relation2id[s3]);
	}
	for (int i = 0; i < relation_num; i++) {
		double sum1 = 0, sum2 = 0;
		for (map<int, int>::iterator it = left_entity[i].begin();
				it != left_entity[i].end(); it++) {
			sum1++;
			sum2 += it->second;
		}
//sum1: the number of unique left entities coupled with this relation
//sum2: total number of times this relation coupled to a left entity
		left_num[i] = sum2 / sum1;
	}
	for (int i = 0; i < relation_num; i++) {
		double sum1 = 0, sum2 = 0;
		for (map<int, int>::iterator it = right_entity[i].begin();
				it != right_entity[i].end(); it++) {
			sum1++;
			sum2 += it->second;
		}
//sum1: the number of unique right entities coupled with this relation
//sum2: total number of times this relation coupled to a right entity
		right_num[i] = sum2 / sum1;
	}
	cout << "relation_num=" << relation_num << endl;
	cout << "entity_num=" << entity_num << endl;
	fclose(f_kb);

	f_kb = fopen((folder + "valid.txt").c_str(), "r");
	while (fscanf(f_kb, "%s", buf) == 1) {
		string s1 = buf;

		fscanf(f_kb, "%s", buf);
		string s3 = buf;

		fscanf(f_kb, "%s", buf);
		string s2 = buf;

		if (entity2id.count(s1) == 0) {
			cout << "miss entity:" << s1 << endl;
		}
		if (entity2id.count(s2) == 0) {
			cout << "miss entity:" << s2 << endl;
		}
		if (relation2id.count(s3) == 0) {
			cout << "miss relation:" << s3 << endl;
			relation2id[s3] = relation_num;
			relation_num++;
		}

		train.addDev(entity2id[s1], entity2id[s2], relation2id[s3]);
	}
	fclose(f_kb);

	f_kb = fopen((folder + "test.txt").c_str(), "r");
	while (fscanf(f_kb, "%s", buf) == 1) {
		string s1 = buf;

		fscanf(f_kb, "%s", buf);
		string s3 = buf;

		fscanf(f_kb, "%s", buf);
		string s2 = buf;

		if (entity2id.count(s1) == 0) {
			cout << "miss entity:" << s1 << endl;
		}
		if (entity2id.count(s2) == 0) {
			cout << "miss entity:" << s2 << endl;
		}
		if (relation2id.count(s3) == 0) {
			cout << "miss relation:" << s3 << endl;
			relation2id[s3] = relation_num;
			relation_num++;
		}
		train.addTest(entity2id[s1], entity2id[s2], relation2id[s3]);
	}
	fclose(f_kb);
}

int ArgPos(char *str, int argc, char **argv) {
	int a;
	for (a = 1; a < argc; a++)
		if (!strcmp(str, argv[a])) {
			if (a == argc - 1) {
				printf("Argument missing for %s\n", str);
				exit(1);
			}
			return a;
		}
	return -1;
}

int main(int argc, char**argv) {
	srand((unsigned) time(NULL));
	int n = 100;
	double rate = 0.001, rateW = 0.000001;
	double margin = 1;
	int i, counter = 0, opt;
	int ah = 1, bh = 1, at = 1, bt = 1, nneg = 1;
	bool l1 = true, rms = true, relGivenSample = true;

	suffix = "GenEv21";	//#16 Relation prediction evaluation + filtered MRR

	if ((i = ArgPos((char *) "-ah", argc, argv)) > 0) {
		ah = atoi(argv[i + 1]);
		suffix += ".ah" + string(argv[i + 1]);
		counter += 1;
	}
	if ((i = ArgPos((char *) "-bh", argc, argv)) > 0) {
		bh = atoi(argv[i + 1]);
		suffix += ".bh" + string(argv[i + 1]);
		counter += 1;
	}
	if ((i = ArgPos((char *) "-at", argc, argv)) > 0) {
		at = atoi(argv[i + 1]);
		suffix += ".at" + string(argv[i + 1]);
		counter += 1;
	}
	if ((i = ArgPos((char *) "-bt", argc, argv)) > 0) {
		bt = atoi(argv[i + 1]);
		suffix += ".bt" + string(argv[i + 1]);
		counter += 1;
	}

	if ((i = ArgPos((char *) "-folder", argc, argv)) > 0) {
		folder = argv[i + 1];
		counter += 1;
	}

	bool ranInit = 0;
	if ((i = ArgPos((char *) "-init", argc, argv)) > 0) {
		ranInit = atoi(argv[i + 1]);
		suffix += ".i_" + string(argv[i + 1]);
		counter += 1;
	}

	if ((i = ArgPos((char *) "-nepoch", argc, argv)) > 0) {
		nepoch = atoi(argv[i + 1]);
		suffix += ".e" + string(argv[i + 1]);
		counter += 1;
	}

	if ((i = ArgPos((char *) "-nneg", argc, argv)) > 0) {
		nneg = atoi(argv[i + 1]);
		suffix += ".nn" + string(argv[i + 1]);
		counter += 1;
	}

	if ((i = ArgPos((char *) "-nthreads", argc, argv)) > 0) {
		nThreads = atoi(argv[i + 1]);
		suffix += ".nt" + string(argv[i + 1]);
		counter += 1;
	}

	double scale = 1;
	if ((i = ArgPos((char *) "-scale", argc, argv)) > 0) {
		scale = atof(argv[i + 1]);
		suffix += ".sc" + string(argv[i + 1]);
		counter += 1;
	}

	if ((i = ArgPos((char *) "-lrate", argc, argv)) > 0) {
		rate = atof(argv[i + 1]);
		suffix += ".r" + string(argv[i + 1]);
		counter += 1;
	}

	if ((i = ArgPos((char *) "-lrateW", argc, argv)) > 0) {
		rateW = atof(argv[i + 1]);
		suffix += ".rw" + string(argv[i + 1]);
		counter += 1;
	}

	if ((i = ArgPos((char *) "-size", argc, argv)) > 0) {
		n = atoi(argv[i + 1]);
		suffix += ".s" + string(argv[i + 1]);
		counter += 1;
	}

	if ((i = ArgPos((char *) "-margin", argc, argv)) > 0) {
		margin = atoi(argv[i + 1]);
		suffix += ".m" + string(argv[i + 1]);
		counter += 1;
	}

	if ((i = ArgPos((char *) "-rms", argc, argv)) > 0) {
		rms = atoi(argv[i + 1]);
		suffix += ".rms" + string(argv[i + 1]);
		counter += 1;
	}

	if ((i = ArgPos((char *) "-l1", argc, argv)) > 0) {
		l1 = atoi(argv[i + 1]);
		suffix += ".l1_" + string(argv[i + 1]);
		counter += 1;
	}

	if ((i = ArgPos((char *) "-rGSam", argc, argv)) > 0) {		//relGivenSample
		relGivenSample = atoi(argv[i + 1]);
		suffix += ".rGS" + string(argv[i + 1]);
		counter += 1;
	}

	if ((i = ArgPos((char *) "-opt", argc, argv)) > 0) {
		opt = atoi(argv[i + 1]);
		suffix += ".opt" + string(argv[i + 1]);
		counter += 1;
	}

	double regularizer = 0.01;
	if ((i = ArgPos((char *) "-regul", argc, argv)) > 0) {
		regularizer = atof(argv[i + 1]);
		suffix += ".re" + string(argv[i + 1]);
		counter += 1;
	}

	int d = 1;
	if ((i = ArgPos((char *) "-d", argc, argv)) > 0) {
		d = atoi(argv[i + 1]);
		suffix += ".d" + string(argv[i + 1]);
		counter += 1;
	}

	if ((i = ArgPos((char *) "-thres", argc, argv)) > 0) {
		threshold = atoi(argv[i + 1]);
		suffix += ".th" + string(argv[i + 1]);
		counter += 1;
	}

	if (counter < 21) {
		cout
				<< "Need to put parameters: -ah, -bh, -at, -bt, -folder, -init, -nepoch, -nneg, -scale, -lrate, -lrateW, -size, -margin, -rms, -l1, -rGSam, -opt, -regul, -d, -thres, -nthreads "
				<< endl;
		return 0;
	}

	cout << "size = " << n << endl;
	cout << "learing rate = " << rate << " lrateW: " << rateW << endl;
	cout << "margin = " << margin << endl;
	cout << "data folder path = " << folder << endl;
	cout << "relGivenSample = " << relGivenSample << endl;
	cout << "nThreads = " << nThreads << endl;
	cout << "suffix = " << suffix << endl;

	prepare(folder);
	train.run(n, rate, rateW, margin, relGivenSample, ah, bh, at, bt, opt, l1,
			rms, nneg, scale, regularizer, d, ranInit);

}

