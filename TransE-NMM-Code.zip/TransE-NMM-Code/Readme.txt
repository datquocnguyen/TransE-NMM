Please find more details in my paper:

@InProceedings{nguyen-EtAl:2016:CoNLL,
  author    = {Nguyen, Dat Quoc  and  Sirts, Kairit  and  Qu, Lizhen  and  Johnson, Mark},
  title     = {Neighborhood Mixture Model for Knowledge Base Completion},
  booktitle = {Proceedings of The 20th SIGNLL Conference on Computational Natural Language Learning},
  month     = {August},
  year      = {2016},
  address   = {Berlin, Germany},
  publisher = {Association for Computational Linguistics},
  pages     = {40--50},
  url       = {http://www.aclweb.org/anthology/K16-1005}
}

There are 3 main files TransE_NMM_vTC (for triple classification), TransE_NMM_vEP (for entity prediction), TransE_NMM_vRP (for relation prediction).

After you compile the source, you can run the models as follow:

./TransE_NMM_vTC -method 1 -opt 1 -ah 1 -bh 1 -at 1 -bt 1 -rms 1 -nneg 1 -step 500 -save 500 -scale 1 -rGSam 0 -init 0 -nepoch 200 -thres 10 -regul 0.01 -d 0 -size 50 -margin 1 -lrate 0.01 -lrateW 0.01 -folder nell186_TC/ -l1 0 

Main hyper-parameters:

-nepoch: number of epoches for each three optimization step
-thres: filtering threshold
-regul: L2 regularizer
-d: hyper-parameter \delta 
-size: number of vector dimensions (vector size)
-margin: hyper-parameter margin
-lrate, -lrateW: learning rate hyper-parameter, should be set to the same value.
-folder: path to the folder containing data
-l1: l1 or l2 norm (0 refers to l2-norm while 1 refers to l1-norm).

There is an extra hyper-parameter ''-nthreads" when running entity prediction or relation-prediction. Because doing evaluation on entity/relation prediction is slow, we can parallelism this process by setting how many CPU cores used for evaluation.

./TransE_NMM_vEP -method 1 -opt 1 -ah 1 -bh 1 -at 1 -bt 1 -rms 1 -nneg 1 -step 500 -save 500 -scale 1 -rGSam 0 -init 0 -nepoch 200 -thres 10 -regul 0.01 -d 0 -size 50 -margin 1 -lrate 0.01 -lrateW 0.01 -folder nell186/ -l1 0 -nthreads 5
